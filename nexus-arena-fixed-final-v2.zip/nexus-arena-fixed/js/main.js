/* ============================================================
   NEXUS ARENA — MAIN JS
   ============================================================ */

// ── UTILITY ─────────────────────────────────────────────────
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

// Inject ambient particle CSS
const particleStyle = document.createElement('style');
particleStyle.textContent = `
  @keyframes particleFloat {
    0%   { transform: translateY(0) translateX(0px); opacity: 0; }
    10%  { opacity: 0.8; }
    50%  { transform: translateY(-50vh) translateX(30px); }
    90%  { opacity: 0.6; }
    100% { transform: translateY(-105vh) translateX(-20px); opacity: 0; }
  }
`;
document.head.appendChild(particleStyle);

function showToast(msg, icon = '⚡') {
  const c = document.getElementById('toast-container');
  const t = document.createElement('div');
  t.className = 'toast';
  t.innerHTML = `<span class="toast-icon">${icon}</span><span class="toast-msg">${msg}</span>`;
  c.appendChild(t);
  setTimeout(() => t.remove(), 3800);
}

// ── PAGE LOADER ──────────────────────────────────────────────
window.addEventListener('load', () => {
  setTimeout(() => {
    const loader = document.getElementById('page-loader');
    if (loader) {
      loader.classList.add('hidden');
      // Trigger entrance animations after loader fades
      setTimeout(() => {
        document.body.classList.add('loaded');
      }, 500);
    }
    document.body.style.overflow = '';
  }, 2200);
});

// ── CUSTOM CURSOR ────────────────────────────────────────────
(function initCursor() {
  const dot  = document.querySelector('.cursor-dot');
  const ring = document.querySelector('.cursor-ring');
  if (!dot || !ring) return;

  let mx = 0, my = 0, rx = 0, ry = 0;

  document.addEventListener('mousemove', e => {
    mx = e.clientX; my = e.clientY;
    dot.style.left = mx + 'px';
    dot.style.top  = my + 'px';
  });

  function animateRing() {
    rx += (mx - rx) * 0.12;
    ry += (my - ry) * 0.12;
    ring.style.left = rx + 'px';
    ring.style.top  = ry + 'px';
    requestAnimationFrame(animateRing);
  }
  animateRing();

  // Scale / lock-on on interactive elements
  const interactables = 'a, button, .btn, .tab-btn, .seat-card, .zone-card, .menu-card, .shop-card, [data-cursor]';
  document.addEventListener('mouseover', e => {
    if (e.target.closest(interactables)) {
      ring.classList.add('locked');
      document.body.classList.add('cursor-locked');
    }
  });

  document.addEventListener('mouseout', e => {
    if (e.target.closest(interactables)) {
      ring.classList.remove('locked');
      document.body.classList.remove('cursor-locked');
    }
  });

  document.addEventListener('mousedown', () => {
    dot.style.transform = 'translate(-50%,-50%) scale(0.7)';
  });
  document.addEventListener('mouseup', () => {
    dot.style.transform = 'translate(-50%,-50%) scale(1)';
  });

  // ── Hit-marker spawner ──────────────────────────────────────
  function spawnHitMarker(x, y, duration) {
    duration = duration || 180;
    const hm = document.createElement('div');
    hm.className = 'hit-marker';
    hm.style.left = x + 'px';
    hm.style.top  = y + 'px';
    hm.style.animationDuration = duration + 'ms';
    document.body.appendChild(hm);
    setTimeout(() => hm.remove(), duration + 20);
  }

  // Click: existing ripple + new hit-marker
  document.addEventListener('click', e => {
    // Existing btn-ripple
    const ripple = document.createElement('div');
    ripple.className = 'btn-ripple';
    ripple.style.left = e.clientX + 'px';
    ripple.style.top = e.clientY + 'px';
    ripple.style.position = 'fixed';
    ripple.style.zIndex = '99997';
    document.body.appendChild(ripple);
    setTimeout(() => ripple.remove(), 600);

    // New hit-marker
    spawnHitMarker(e.clientX, e.clientY);
  });
})();

// ── SCROLL PROGRESS ──────────────────────────────────────────
(function initProgress() {
  const bar = document.getElementById('progress-bar');
  if (!bar) return;
  window.addEventListener('scroll', () => {
    const h = document.documentElement;
    const pct = (h.scrollTop / (h.scrollHeight - h.clientHeight)) * 100;
    bar.style.width = pct + '%';
  });
})();

// ── NAVBAR ───────────────────────────────────────────────────
(function initNavbar() {
  const nav = document.getElementById('navbar');
  const ham = document.getElementById('hamburger');
  const mobileNav = document.getElementById('mobile-nav');

  window.addEventListener('scroll', () => {
    if (window.scrollY > 60) {
      nav.classList.add('scrolled');
    } else {
      nav.classList.remove('scrolled');
    }
  });

  if (ham && mobileNav) {
    const setMobileNav = isOpen => {
      ham.classList.toggle('open', isOpen);
      mobileNav.classList.toggle('open', isOpen);
      ham.setAttribute('aria-expanded', String(isOpen));
      ham.setAttribute('aria-label', isOpen ? 'Close navigation menu' : 'Open navigation menu');
    };

    ham.addEventListener('click', () => {
      setMobileNav(!mobileNav.classList.contains('open'));
    });

    // Close on link click
    $$('a', mobileNav).forEach(a => {
      a.addEventListener('click', () => {
        setMobileNav(false);
      });
    });

    window.addEventListener('keydown', event => {
      if (event.key === 'Escape' && mobileNav.classList.contains('open')) {
        setMobileNav(false);
        ham.focus();
      }
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth > 1300) setMobileNav(false);
    });
  }

  // Active link highlight
  const sections = $$('section[id]');
  const navLinks = $$('#navbar .nav-links a, #mobile-nav a');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        navLinks.forEach(a => {
          a.classList.remove('active');
          if (a.getAttribute('href') === '#' + e.target.id) {
            a.classList.add('active');
          }
        });
      }
    });
  }, { threshold: 0.3 });

  sections.forEach(s => observer.observe(s));
})();

// ── SCROLL REVEAL ────────────────────────────────────────────
(function initReveal() {
  const revealEls = $$('.reveal, .reveal-left, .reveal-right, .stagger');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        observer.unobserve(e.target);
      }
    });
  }, { threshold: 0.1 });

  revealEls.forEach(el => observer.observe(el));
})();

// ── SCROLL TO TOP ─────────────────────────────────────────────
(function initScrollTop() {
  const btn = document.getElementById('scroll-top');
  if (!btn) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 500) btn.classList.add('visible');
    else btn.classList.remove('visible');
  });

  btn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
})();

// ── PARALLAX ELEMENTS ────────────────────────────────────────
(function initParallax() {
  const parallaxEls = document.querySelectorAll('.hero-ring, .hero-bg-gradient');
  if (!parallaxEls.length) return;

  let ticking = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        const scrollY = window.scrollY;
        parallaxEls.forEach(el => {
          const speed = el.classList.contains('hero-bg-gradient') ? 0.3 : 0.15;
          el.style.transform = `translateY(${scrollY * speed}px)`;
        });
        ticking = false;
      });
      ticking = true;
    }
  });
})();

// ── TABS ─────────────────────────────────────────────────────
(function initTabs() {
  $$('[data-tab-group]').forEach(group => {
    const groupName = group.dataset.tabGroup;
    const buttons   = $$(`[data-tab-group="${groupName}"] .tab-btn`);
    const panes     = $$(`[data-tab-panes="${groupName}"] .tab-pane`);

    buttons.forEach((btn, i) => {
      btn.addEventListener('click', () => {
        buttons.forEach(b => b.classList.remove('active'));
        panes.forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        if (panes[i]) panes[i].classList.add('active');
      });
    });
  });
})();

// ── ANIMATED COUNTERS ─────────────────────────────────────────
function animateCounter(el, target, duration = 2000, prefix = '', suffix = '') {
  let start = 0;
  const startTime = performance.now();
  const isFloat = target % 1 !== 0;

  function update(now) {
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const ease = 1 - Math.pow(1 - progress, 3);
    const current = ease * target;
    el.textContent = prefix + (isFloat ? current.toFixed(1) : Math.floor(current).toLocaleString()) + suffix;
    if (progress < 1) requestAnimationFrame(update);
  }

  requestAnimationFrame(update);
}

function initCounters() {
  const counters = $$('[data-counter]');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        const el = e.target;
        const val = parseFloat(el.dataset.counter);
        const prefix = el.dataset.prefix || '';
        const suffix = el.dataset.suffix || '';
        animateCounter(el, val, 2000, prefix, suffix);
        observer.unobserve(el);
      }
    });
  }, { threshold: 0.5 });

  counters.forEach(c => observer.observe(c));
}

// ── HERO TYPING TEXT ─────────────────────────────────────────
(function initTyping() {
  const el = document.getElementById('hero-tagline');
  if (!el) return;

  const phrases = [
    'Play Beyond Reality',
    'Where Legends Are Forged',
    "India's #1 Gaming Arena",
    'Compete • Conquer • Dominate',
    'Your Next Level Awaits',
    '50+ High-End Gaming PCs',
    'Open 24/7 • Never Closes'
  ];

  let pi = 0, ci = 0, deleting = false;

  function type() {
    const current = phrases[pi];
    if (!deleting) {
      el.textContent = current.slice(0, ci + 1);
      ci++;
      if (ci === current.length) {
        deleting = true;
        setTimeout(type, 2200);
        return;
      }
    } else {
      el.textContent = current.slice(0, ci - 1);
      ci--;
      if (ci === 0) {
        deleting = false;
        pi = (pi + 1) % phrases.length;
      }
    }
    setTimeout(type, deleting ? 55 : 80);
  }

  type();
})();

// ── LIVE HERO STATS ───────────────────────────────────────────
(function initHeroStats() {
  const stats = {
    visitors: { el: document.getElementById('live-visitors'), base: 1247, variance: 5 },
    online:   { el: document.getElementById('live-online'),   base: 89,   variance: 3 },
    matches:  { el: document.getElementById('live-matches'),  base: 23,   variance: 2 }
  };

  function update() {
    Object.values(stats).forEach(s => {
      if (!s.el) return;
      const delta = Math.floor((Math.random() - 0.4) * s.variance);
      s.base = Math.max(0, s.base + delta);
      s.el.textContent = s.base.toLocaleString();
    });
  }

  update();
  setInterval(update, 3000);
})();

// ── MODAL SYSTEM ─────────────────────────────────────────────
window.openModal = function(id) {
  const modal = document.getElementById(id);
  if (modal) {
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
};

window.closeModal = function(id) {
  const modal = document.getElementById(id);
  if (modal) {
    modal.classList.remove('open');
    document.body.style.overflow = '';
  }
};

// Close on overlay click
$$('.modal-overlay').forEach(m => {
  m.addEventListener('click', e => {
    if (e.target === m) closeModal(m.id);
  });
});

// Close on Escape
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    $$('.modal-overlay.open').forEach(m => closeModal(m.id));
  }
});

// ── 3D TILT EFFECT ─────────────────────────────────────────────
(function initTilt() {
  const tiltEls = document.querySelectorAll('[data-tilt]');
  tiltEls.forEach(el => {
    el.addEventListener('mousemove', e => {
      const rect = el.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      const tiltX = ((y - centerY) / centerY) * 12; // max 12 deg
      const tiltY = ((centerX - x) / centerX) * -12; // inverted for correct axis
      
      el.style.transform = `perspective(1000px) rotateX(${tiltX}deg) rotateY(${tiltY}deg) translateY(-12px) scale(1.03)`;
      el.style.transition = 'transform 0.1s cubic-bezier(0.23, 1, 0.32, 1), box-shadow 0.4s ease, border-color 0.4s ease';
    });
    
    el.addEventListener('mouseleave', () => {
      el.style.transform = '';
      el.style.transition = ''; // Restore CSS defined transition
    });
  });
})();
// ── SMOOTH SCROLL FOR NAV LINKS ───────────────────────────────
$$('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

// ── AMBIENT FLOATING PARTICLES ───────────────────────────────
(function initAmbientParticles() {
  const container = document.getElementById('ambient-particles');
  if (!container) return;

  const PARTICLE_COUNT = 25;
  const colors = ['rgba(0,212,255,0.3)', 'rgba(124,58,237,0.25)', 'rgba(255,0,110,0.2)', 'rgba(0,255,136,0.15)'];

  for (let i = 0; i < PARTICLE_COUNT; i++) {
    const p = document.createElement('div');
    const size = 2 + Math.random() * 4;
    const color = colors[Math.floor(Math.random() * colors.length)];
    const left = Math.random() * 100;
    const delay = Math.random() * 20;
    const duration = 15 + Math.random() * 25;

    p.style.cssText = `
      position: absolute;
      width: ${size}px;
      height: ${size}px;
      background: ${color};
      border-radius: 50%;
      left: ${left}%;
      bottom: -10px;
      opacity: 0;
      box-shadow: 0 0 ${size * 3}px ${color};
      animation: particleFloat ${duration}s linear ${delay}s infinite;
    `;
    container.appendChild(p);
  }
})();

// ── INIT ─────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initCounters();

  // Hide loader initially
  document.body.style.overflow = 'hidden';

  // ── INLINE ONCLICK REPLACEMENTS ─────────────────────────────

  // Nav: Login button
  const navLoginBtn = document.getElementById('nav-login-btn');
  if (navLoginBtn) navLoginBtn.addEventListener('click', () => {
    if (typeof openAuthModal === 'function') openAuthModal();
  });

  // Nav: User/Dashboard button
  const navUserBtn = document.getElementById('nav-user-btn');
  if (navUserBtn) navUserBtn.addEventListener('click', () => {
    if (typeof openDashboard === 'function') openDashboard();
  });

  // Nav: Book Now button — scroll to booking
  const navBookBtn = document.getElementById('nav-book-btn');
  if (navBookBtn) navBookBtn.addEventListener('click', () => {
    document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' });
  });

  // Zone cards: all "Book Now" / "Book * Seat" buttons
  document.querySelectorAll('.js-book-now').forEach(btn => {
    btn.addEventListener('click', () => {
      document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' });
    });
  });

  // Shop: View Cart button
  const shopCartBtn = document.querySelector('#shop .btn-outline');
  if (shopCartBtn) shopCartBtn.addEventListener('click', () => {
    if (typeof viewCart === 'function') viewCart();
  });

  // Cart float bar: View button
  const cartFloatBtn = document.querySelector('#cart-float .btn-primary');
  if (cartFloatBtn) cartFloatBtn.addEventListener('click', () => {
    if (typeof viewCart === 'function') viewCart();
  });

  // Contact form: Send Message button
  const contactSendBtn = document.querySelector('.contact-form-wrap .btn-primary');
  if (contactSendBtn) contactSendBtn.addEventListener('click', (e) => {
    e.preventDefault();
    showToast("Message sent! We'll reply within 2 hours 📨", '✅');
  });

  // Newsletter: Subscribe button
  const newsletterBtn = document.querySelector('.newsletter-btn');
  if (newsletterBtn) newsletterBtn.addEventListener('click', () => {
    showToast('Subscribed! Check your inbox 📬', '✅');
  });
});

// ── REVIEW CARD GLOW TRACKING ────────────────────────────────
(function initReviewGlow() {
  document.querySelectorAll('.review-card').forEach(card => {
    card.addEventListener('mousemove', e => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      card.style.setProperty('--mouse-x', `${x}px`);
      card.style.setProperty('--mouse-y', `${y}px`);
    });
  });
})();

// ── NEXUS CAFÉ — Quantity controls & Add-to-cart feedback ────
(function initNexusCafe() {
  document.addEventListener('click', function(e) {

    // ── Quantity minus ─────────────────────────────────────
    if (e.target.closest('.cafe-qty-btn[data-action="minus"]')) {
      const btn = e.target.closest('.cafe-qty-btn');
      const valEl = btn.parentElement.querySelector('.cafe-qty-val');
      let qty = parseInt(valEl.textContent, 10);
      if (qty > 1) { valEl.textContent = qty - 1; }
      return;
    }

    // ── Quantity plus ──────────────────────────────────────
    if (e.target.closest('.cafe-qty-btn[data-action="plus"]')) {
      const btn = e.target.closest('.cafe-qty-btn');
      const valEl = btn.parentElement.querySelector('.cafe-qty-val');
      let qty = parseInt(valEl.textContent, 10);
      if (qty < 20) { valEl.textContent = qty + 1; }
      return;
    }

    // ── Add to cart button ─────────────────────────────────
    if (e.target.closest('.cafe-add-btn')) {
      const btn = e.target.closest('.cafe-add-btn');
      if (btn.classList.contains('cafe-added')) return;

      const card    = btn.closest('.cafe-card');
      const name    = card.querySelector('.cafe-card-name').textContent.trim();
      const qty     = parseInt(card.querySelector('.cafe-qty-val').textContent, 10);
      const price   = card.querySelector('.cafe-card-price').dataset.price || '';

      // Visual confirmation
      const origHTML = btn.innerHTML;
      btn.classList.add('cafe-added');
      btn.innerHTML = '<i class="fas fa-check"></i> ADDED!';
      setTimeout(() => {
        btn.classList.remove('cafe-added');
        btn.innerHTML = origHTML;
      }, 1800);

      // Fire a toast using existing showToast if available
      if (typeof showToast === 'function') {
        showToast(`${qty}× ${name} added to cart`, '🍔');
      }
    }
  });
})();

