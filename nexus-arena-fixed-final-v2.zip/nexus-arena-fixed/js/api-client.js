/* NEXUS ARENA — PYTHON API CLIENT */
(function () {
  const isBackend = /:(5000)(\/|$)/.test(window.location.host);
  const API_BASE = window.NEXUS_API_BASE ||
    (isBackend ? '/api' : `${window.location.protocol}//${window.location.hostname || '127.0.0.1'}:5000/api`);

  function getToken() { return localStorage.getItem('nexusApiToken'); }
  function setToken(token) {
    if (token) localStorage.setItem('nexusApiToken', token);
    else localStorage.removeItem('nexusApiToken');
  }
  function getUser() {
    try { return JSON.parse(localStorage.getItem('nexusApiUser') || 'null'); }
    catch (_) { return null; }
  }
  function setUser(user) {
    if (user) localStorage.setItem('nexusApiUser', JSON.stringify(user));
    else localStorage.removeItem('nexusApiUser');
  }

  async function request(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    const token = getToken();
    if (token) headers.Authorization = 'Bearer ' + token;

    let response;
    try {
      response = await fetch(API_BASE + path, { ...options, headers });
    } catch (_) {
      throw new Error('Cannot reach the Python backend. Start backend/app.py on port 5000.');
    }

    let data = {};
    try { data = await response.json(); } catch (_) {}
    if (response.status === 401) {
      setToken(null);
      setUser(null);
      window.dispatchEvent(new Event('nexus-auth-changed'));
    }
    if (!response.ok) throw new Error(data.error || 'Backend request failed.');
    return data;
  }

  async function syncMe() {
    if (!getToken()) return null;
    const data = await request('/auth/me');
    setUser(data.user);
    return data.user;
  }

  window.NexusAPI = {
    base: API_BASE,
    request,
    getToken,
    setToken,
    getUser,
    setUser,
    syncMe,
    current: getUser
  };
})();
