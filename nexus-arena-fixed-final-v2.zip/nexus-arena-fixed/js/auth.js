/* NEXUS ARENA — PYTHON API AUTHENTICATION */
(function initAuth() {
  const loginBtn = document.getElementById('nav-login-btn');
  const userBtn = document.getElementById('nav-user-btn');
  const userNameEl = document.getElementById('nav-username');
  const authTabs = document.querySelectorAll('.auth-tab-btn');
  const loginForm = document.getElementById('login-form');
  const signupForm = document.getElementById('signup-form');
  const loginError = document.getElementById('login-error');
  const signupError = document.getElementById('signup-error');
  const toggle = document.getElementById('auth-toggle-indicator');

  const setUser = (u) => {
    window.NexusAPI.setUser(u);
    if (u) localStorage.setItem('nexusApiUser', JSON.stringify(u));
  };

  function refresh(user) {
    if (loginBtn) loginBtn.style.display = user ? 'none' : 'flex';
    if (userBtn) userBtn.style.display = user ? 'flex' : 'none';
    if (userNameEl) userNameEl.textContent = user?.username || 'Dashboard';
    if (window.updateRewardProfile) window.updateRewardProfile(user || {});
  }

  authTabs.forEach((tab, index) => tab.addEventListener('click', () => {
    authTabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    if (toggle) toggle.style.transform = `translateX(${index * 100}%)`;
    const target = tab.dataset.authTab;
    if (loginForm) loginForm.style.display = target === 'login' ? 'block' : 'none';
    if (signupForm) signupForm.style.display = target === 'signup' ? 'block' : 'none';
  }));

  window.handleSignup = async function (e) {
    e.preventDefault();
    if (signupError) signupError.textContent = '';
    const username = document.getElementById('signup-username').value.trim();
    const email = document.getElementById('signup-email').value.trim();
    const password = document.getElementById('signup-password').value;
    const birthday = document.getElementById('signup-birthday')?.value || '';
    try {
      const d = await window.NexusAPI.request('/auth/register', {
        method: 'POST',
        body: JSON.stringify({ username, email, password, birthday })
      });
      window.NexusAPI.setToken(d.token);
      setUser(d.user);
      refresh(d.user);
      closeModal('auth-modal');
      window.NexusAuth.notify();
      showToast(`Welcome to NEXUS ARENA, ${d.user.username}! 🎮`, '🎉');
    } catch (err) {
      if (signupError) signupError.textContent = err.message;
    }
  };

  window.handleLogin = async function (e) {
    e.preventDefault();
    if (loginError) loginError.textContent = '';
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    try {
      const d = await window.NexusAPI.request('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });
      window.NexusAPI.setToken(d.token);
      setUser(d.user);
      refresh(d.user);
      closeModal('auth-modal');
      window.NexusAuth.notify();
      showToast('Welcome back, gamer! ⚡', '🎮');
    } catch (err) {
      if (loginError) loginError.textContent = err.message;
    }
  };

  window.handleLogout = function () { openModal('logout-modal'); };

  window.confirmLogout = async function () {
    try { await window.NexusAPI.request('/auth/logout', { method: 'POST' }); } catch (_) {}
    window.NexusAPI.setToken(null);
    window.NexusAPI.setUser(null);
    window.NexusAuth.notify();
    closeModal('logout-modal');
    closeModal('dashboard-modal');
    showToast('Logged out. See you soon! 👋', '🔒');
  };

  window.openAuthModal = function () { openModal('auth-modal'); };

  async function boot() {
    let user = window.NexusAPI.current();
    if (window.NexusAPI.getToken()) {
      try { user = await window.NexusAPI.syncMe(); }
      catch (err) {
        // Keep the local session during a temporary backend outage.
        // NexusAPI already clears the session on an actual HTTP 401.
        user = window.NexusAPI.getUser() || user;
      }
    }
    refresh(user);
    window.NexusAuth.notify();
  }
  boot();
})();
