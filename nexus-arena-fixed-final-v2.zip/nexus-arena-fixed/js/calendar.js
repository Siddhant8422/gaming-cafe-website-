// ADD CALENDAR LOGIC
window.currentCalEvent = null;

window.addToCalendar = function(title, dateStr, timeStr, durationMinutes) {
  window.currentCalEvent = { title, dateStr, timeStr, durationMinutes };
  
  const el = document.getElementById('cal-event-name');
  if (el) el.textContent = title;
  
  document.getElementById('cal-added-msg').style.display = 'none';
  openModal('calendar-modal');
};

function formatCalDate(dateStr, timeStr) {
  // Returns YYYYMMDDTHHMMSSZ string
  const d = new Date(`${dateStr}T${timeStr}`);
  return d.toISOString().replace(/-|:|\.\d\d\d/g, '');
}

window.addCalGoogle = function() {
  const ev = window.currentCalEvent;
  if(!ev) return;
  const start = formatCalDate(ev.dateStr, ev.timeStr);
  const endD = new Date(new Date(`${ev.dateStr}T${ev.timeStr}`).getTime() + ev.durationMinutes * 60000);
  const end = endD.toISOString().replace(/-|:|\.\d\d\d/g, '');
  const url = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(ev.title)}&dates=${start}/${end}&details=Event+at+Nexus+Arena`;
  window.open(url, '_blank');
  showCalAdded();
};

window.addCalApple = function() { addCalICS(); };
window.addCalOutlook = function() {
  const ev = window.currentCalEvent;
  if(!ev) return;
  const start = formatCalDate(ev.dateStr, ev.timeStr);
  const endD = new Date(new Date(`${ev.dateStr}T${ev.timeStr}`).getTime() + ev.durationMinutes * 60000);
  const end = endD.toISOString().replace(/-|:|\.\d\d\d/g, '');
  const url = `https://outlook.live.com/calendar/0/deeplink/compose?path=/calendar/action/compose&rru=addevent&subject=${encodeURIComponent(ev.title)}&startdt=${start}&enddt=${end}&body=Event+at+Nexus+Arena`;
  window.open(url, '_blank');
  showCalAdded();
};

window.addCalICS = function() {
  const ev = window.currentCalEvent;
  if(!ev) return;
  const start = formatCalDate(ev.dateStr, ev.timeStr);
  const endD = new Date(new Date(`${ev.dateStr}T${ev.timeStr}`).getTime() + ev.durationMinutes * 60000);
  const end = endD.toISOString().replace(/-|:|\.\d\d\d/g, '');
  
  const icsMsg = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'BEGIN:VEVENT',
    'DTSTART:' + start,
    'DTEND:' + end,
    'SUMMARY:' + ev.title,
    'DESCRIPTION:Event at Nexus Arena',
    'END:VEVENT',
    'END:VCALENDAR'
  ].join('\n');
  
  const blob = new Blob([icsMsg], { type: 'text/calendar' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = ev.title.replace(/\s+/g, '') + '.ics';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  showCalAdded();
};

function showCalAdded() {
  const el = document.getElementById('cal-added-msg');
  if (el) el.style.display = 'block';
  setTimeout(() => closeModal('calendar-modal'), 2000);
}
