/* ============================================================
   NEXUS ARENA — LEADERBOARD JS (Local Frontend Edition)
   ============================================================ */

(function initLeaderboard() {
  const fallbackPlayers = [
    { name: 'SHADOW_KING', clan: 'NEXUS ELITE', xp: 24580, wins: 142, avatar: '👑', tier: 'Nexus Pro', status: 'live' },
    { name: 'CyberNinja',  clan: 'DARK FORCE',  xp: 21340, wins: 128, avatar: '⚔️', tier: 'Diamond I', status: 'offline' },
    { name: 'PhantomX',    clan: 'NEXUS ELITE', xp: 19870, wins: 115, avatar: '👻', tier: 'Diamond II', status: 'live' },
    { name: 'BlazeMaster', clan: 'FIRE SQUAD',  xp: 18200, wins: 108, avatar: '🔥', tier: 'Platinum I', status: 'in-game' },
    { name: 'AceStrike',   clan: 'THUNDER',     xp: 17500, wins: 101, avatar: '⚡', tier: 'Platinum II', status: 'offline' },
    { name: 'VortexQueen', clan: 'NEXUS ELITE', xp: 16890, wins: 96,  avatar: '🌀', tier: 'Gold I', status: 'live' },
    { name: 'IronWolf',    clan: 'WOLF PACK',   xp: 15240, wins: 89,  avatar: '🐺', tier: 'Gold II', status: 'in-game' },
    { name: 'NovaBurst',   clan: 'STAR CLAN',   xp: 14100, wins: 82,  avatar: '💫', tier: 'Gold III', status: 'offline' },
    { name: 'DarkPhoenix', clan: 'DARK FORCE',  xp: 13450, wins: 76,  avatar: '🦅', tier: 'Silver I', status: 'live' },
    { name: 'PixelKnight', clan: 'PIXEL ARMY',  xp: 12800, wins: 71,  avatar: '🛡️', tier: 'Bronze I', status: 'offline' },
  ];

  function getStatusDot(status) {
    if (status === 'live') return '<span class="status-dot status-available"></span>';
    if (status === 'in-game') return '<span class="status-dot status-busy"></span>';
    return '<span class="status-dot status-maintenance"></span>';
  }

  function renderLeaderboard(players) {
    const container = document.getElementById('leaderboard-content');
    if (!container) return;
    
    // Top 3 Podium
    const top3 = players.slice(0, 3);
    const podiumHtml = `
      <div class="lb-podium">
        ${top3[1] ? renderPodiumCard(top3[1], 2) : ''}
        ${top3[0] ? renderPodiumCard(top3[0], 1) : ''}
        ${top3[2] ? renderPodiumCard(top3[2], 3) : ''}
      </div>
    `;

    // Rank 4-10
    const rest = players.slice(3, 10);
    const listHtml = `
      <div class="lb-list-header">
        <div class="lb-col-rank">Rank</div>
        <div class="lb-col-player">Player</div>
        <div class="lb-col-xp">Total XP</div>
        <div class="lb-col-hours">Wins</div>
        <div class="lb-col-tier">Status/Tier</div>
      </div>
      <div class="lb-list">
        ${rest.map((p, i) => renderListRow(p, i + 4)).join('')}
      </div>
    `;

    container.innerHTML = podiumHtml + listHtml;
  }

  function renderPodiumCard(p, rank) {
    const avatar = p.avatar || (p.name || p.username || 'U').charAt(0).toUpperCase();
    const rankClass = rank === 1 ? 'gold' : rank === 2 ? 'silver' : 'bronze';
    const crown = rank === 1 ? '👑' : rank === 2 ? '🥈' : '🥉';
    return `
      <div class="podium-card rank-${rankClass}">
        <div class="podium-rank-icon">${crown}</div>
        <div class="podium-avatar-wrapper">
          <div class="podium-avatar" style="font-size:1.5rem">${avatar}</div>
          <div class="podium-status">${getStatusDot(p.status || 'offline')}</div>
        </div>
        <div class="podium-name">${p.name || p.username}</div>
        <div class="podium-clan">${p.clan || 'NO CLAN'}</div>
        
        <div class="podium-stats">
          <div class="podium-stat-col">
            <span class="stat-label">Total XP</span>
            <span class="stat-value text-neon-cyan">${(p.xp || 0).toLocaleString()}</span>
          </div>
          <div class="podium-stat-col">
            <span class="stat-label">Wins</span>
            <span class="stat-value">${p.wins || 0}</span>
          </div>
        </div>
        <div class="podium-tier">${p.tier || 'Unranked'}</div>
      </div>
    `;
  }

  function renderListRow(p, rank) {
    const avatar = p.avatar || (p.name || p.username || 'U').charAt(0).toUpperCase();
    return `
      <div class="lb-row">
        <div class="lb-col-rank rank-num">#${rank}</div>
        <div class="lb-col-player">
          <div class="lb-avatar">${avatar}</div>
          <div>
            <div class="lb-name">${p.name || p.username}</div>
            <div class="lb-clan">${p.clan || 'NO CLAN'}</div>
          </div>
        </div>
        <div class="lb-col-xp lb-xp">${(p.xp || 0).toLocaleString()}</div>
        <div class="lb-col-hours lb-hours">${p.wins || 0}</div>
        <div class="lb-col-tier lb-tier">
          ${getStatusDot(p.status || 'offline')} ${p.tier || 'Unranked'}
        </div>
      </div>
    `;
  }
  renderLeaderboard(fallbackPlayers);
  if (window.NexusAPI) {
    window.NexusAPI.request('/leaderboard').then(d => renderLeaderboard(d.players || fallbackPlayers))
      .catch(err => console.warn('Leaderboard API unavailable:', err));
  }

  // Sliding Indicator Logic for Leaderboard Tabs
  setTimeout(() => {
    const tabs = document.querySelector('.tabs[data-tab-group="lb"]');
    if (tabs) {
      const updateIndicator = (activeBtn) => {
        if (!activeBtn) return;
        const width = activeBtn.offsetWidth;
        const left = activeBtn.offsetLeft - 4; // account for padding
        tabs.style.setProperty('--indicator-width', `${width}px`);
        tabs.style.setProperty('--indicator-left', `${left}px`);
      };
      
      const btns = tabs.querySelectorAll('.tab-btn');
      const active = tabs.querySelector('.tab-btn.active');
      updateIndicator(active);
      
      btns.forEach(btn => {
        btn.addEventListener('click', (e) => {
          btns.forEach(b => b.classList.remove('active'));
          e.target.classList.add('active');
          updateIndicator(e.target);
          // Normally would fetch data for new tab here
          // renderLeaderboard(newData);
        });
      });
      
      window.addEventListener('resize', () => {
        updateIndicator(tabs.querySelector('.tab-btn.active'));
      });
    }
  }, 100);
})();
