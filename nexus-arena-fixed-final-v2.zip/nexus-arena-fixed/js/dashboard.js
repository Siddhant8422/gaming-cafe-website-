/* NEXUS ARENA — PYTHON API DASHBOARD */
(function initDashboard() {
  const defaults = {
    username: 'Guest', level: 0, xp: 0, xpNext: 1000, rank: 'N/A',
    membership: 'NONE', wallet: 0, points: 0, totalHours: 0, wins: 0,
    bookings: [], orders: [], achievements: []
  };

  document.querySelectorAll('[data-dash-tab]').forEach(tab => tab.addEventListener('click', () => {
    document.querySelectorAll('[data-dash-tab]').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const target = tab.dataset.dashTab;
    ['bookings', 'orders', 'rewards'].forEach(k => {
      const el = document.getElementById('dash-tab-' + k);
      if (el) el.style.display = target === k ? 'block' : 'none';
    });
  }));

  function render(d) {
    const avatar = document.getElementById('dash-avatar');
    const uname = document.getElementById('dash-username');
    const level = document.getElementById('dash-level');
    const mem = document.getElementById('dash-membership');
    const bar = document.getElementById('dash-xp-bar');
    const label = document.getElementById('dash-xp-label');

    if (avatar) avatar.textContent = (d.username || 'G').slice(0, 2).toUpperCase();
    if (uname) uname.textContent = d.username || 'Guest';
    if (level) level.textContent = `Level ${d.level || 0} • Rank ${d.rank || 'N/A'}`;
    if (mem) mem.textContent = d.membership || 'NONE';
    if (label) label.textContent = `${(d.xp || 0).toLocaleString()} / ${(d.xpNext || 1000).toLocaleString()} XP`;
    if (bar) setTimeout(() => bar.style.width = Math.min(100, ((d.xp || 0) / (d.xpNext || 1000)) * 100) + '%', 100);

    document.querySelectorAll('[data-dash-stat]').forEach(el => {
      const k = el.dataset.dashStat;
      if (d[k] !== undefined) el.textContent = typeof d[k] === 'number' ? d[k].toLocaleString() : d[k];
    });

    const rp = document.getElementById('dash-reward-points');
    if (rp) rp.textContent = (d.points || 0).toLocaleString();

    if (window.updateRewardProfile) window.updateRewardProfile(d);

    const bookings = document.getElementById('dash-bookings');
    if (bookings) bookings.innerHTML = d.bookings.length
      ? d.bookings.map(b => `<div class="booking-item"><span class="booking-icon">${b.icon || '🎮'}</span><div class="booking-info"><div class="booking-name">${b.name || 'Gaming Session'}</div><div class="booking-time">${b.date || 'Upcoming'}, ${b.time || ''} • ${b.duration || 1} hr(s)</div></div><span class="badge badge-green">${b.status || 'Confirmed'}</span></div>`).join('')
      : '<p style="color:rgba(255,255,255,.4);font-size:.85rem;text-align:center;padding:20px;">No bookings yet. Book a session!</p>';

    const orders = document.getElementById('dash-orders');
    if (orders) orders.innerHTML = d.orders.length
      ? d.orders.map(o => `<div class="booking-item"><span class="booking-icon" style="background:rgba(0,212,255,.1);color:var(--neon-cyan);">🛍️</span><div class="booking-info"><div class="booking-name">${(o.items || []).map(i => `${i.qty}× ${i.name}`).join(', ') || 'Pro Store order'}</div><div class="booking-time">${o.createdAt ? new Date(o.createdAt).toLocaleString() : 'Recent'}</div></div><span class="badge badge-cyan">₹${Number(o.total || 0).toLocaleString('en-IN')}</span></div>`).join('')
      : '<p style="color:rgba(255,255,255,.4);font-size:.85rem;text-align:center;padding:20px;">No recent store orders.</p>';

    const ach = document.getElementById('dash-achievements');
    if (ach) ach.innerHTML = d.achievements.length
      ? d.achievements.map(a => `<div class="booking-item"><span style="font-size:1.3rem;">${a.badge}</span><div class="booking-info"><div class="booking-name">${a.name}</div><div class="booking-time">${a.date}</div></div></div>`).join('')
      : '<p style="color:rgba(255,255,255,.4);font-size:.85rem;text-align:center;padding:20px;">Play more to unlock achievements! 🏆</p>';
  }

  async function loadDashboard() {
    const user = window.NexusAPI.current();
    if (!user || !window.NexusAPI.getToken()) {
      render(defaults);
      return;
    }
    try {
      const data = await window.NexusAPI.request('/dashboard');
      const d = { ...defaults, ...(data.user || {}) };
      d.bookings = Array.isArray(data.bookings) ? data.bookings : [];
      d.orders = Array.isArray(data.orders) ? data.orders : [];
      d.achievements = [
        ...(d.totalHours >= 10 ? [{ badge: '⏰', name: '10 Hour Gamer', date: 'Unlocked' }] : []),
        ...(d.totalHours >= 50 ? [{ badge: '🌙', name: 'Night Owl', date: 'Unlocked' }] : []),
        ...(d.wins >= 10 ? [{ badge: '🏆', name: '10 Wins', date: 'Unlocked' }] : []),
        ...(d.xp >= 5000 ? [{ badge: '⚡', name: 'XP Master', date: 'Unlocked' }] : [])
      ];
      window.NexusAPI.setUser(data.user);
      render(d);
    } catch (err) {
      showToast(err.message, '⚠️');
    }
  }

  window.openDashboard = async function () {
    await loadDashboard();
    openModal('dashboard-modal');
  };

  window.addEventListener('nexus-auth-changed', () => {
    if (document.getElementById('dashboard-modal')?.classList.contains('open')) loadDashboard();
  });
})();
