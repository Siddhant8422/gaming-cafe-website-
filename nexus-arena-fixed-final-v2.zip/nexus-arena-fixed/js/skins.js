// ── SKINS & TOP-UP LOGIC ─────────────────────────────────────────

window.currentSkinItem = null;

window.buySkin = function(game, itemName, price) {
  window.currentSkinItem = { game, itemName, price };
  
  // Open the In-Game ID Modal
  const info = document.getElementById('ingame-skin-info');
  if (info) {
    info.innerHTML = `You are purchasing: <strong>${itemName}</strong> for <strong>&#8377;${price}</strong>`;
  }
  
  const gameSelect = document.getElementById('ingame-game');
  if (gameSelect) {
    gameSelect.value = game;
  }
  
  document.getElementById('ingame-uid').value = '';
  document.getElementById('ingame-uid-confirm').value = '';
  
  openModal('ingame-modal');
};

window.confirmSkinPurchase = function() {
  const uid = document.getElementById('ingame-uid').value.trim();
  const uidConfirm = document.getElementById('ingame-uid-confirm').value.trim();
  const game = document.getElementById('ingame-game').value;
  
  if (!game) { showToast('Please select a game!', '⚠️'); return; }
  if (!uid || !uidConfirm) { showToast('Please enter your In-Game ID in both fields!', '⚠️'); return; }
  if (uid !== uidConfirm) { showToast('In-Game IDs do not match!', '⚠️'); return; }
  
  // All good, mock purchase
  closeModal('ingame-modal');
  
  showToast('Processing purchase...', '⏳');
  setTimeout(() => {
    showToast(`Success! ${window.currentSkinItem.itemName} has been credited to ${uid} (${game}).`, '✅');
  }, 1500);
};
