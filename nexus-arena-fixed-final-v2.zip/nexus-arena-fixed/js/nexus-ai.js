/* NEXUS AI — client-side copilot shell. Backend endpoint can be configured later. */
(function(){
  if(document.getElementById('nexus-ai')) return;
  const page=(location.pathname+location.hash).toLowerCase();
  const context=page.includes('/store/')?'PRO STORE':page.includes('tournament')?'TOURNAMENTS':page.includes('booking')?'BOOKING':'NEXUS ARENA';
  const root=document.createElement('div');root.id='nexus-ai';root.className='nx-ai';
  root.innerHTML=`
    <div class="nx-ai-panel" role="dialog" aria-label="Nexus AI Copilot">
      <div class="nx-ai-head"><div class="nx-ai-avatar">N</div><div><div class="nx-ai-title">NEXUS AI</div><div class="nx-ai-sub">Gaming Café Copilot · ${context}</div></div><button class="nx-ai-close" aria-label="Close">×</button></div>
      <div class="nx-ai-context"><span>Context-aware assistance</span><span class="nx-ai-live">ONLINE</span></div>
      <div class="nx-ai-messages" id="nx-ai-messages"></div>
      <div class="nx-ai-quick" id="nx-ai-quick"></div>
      <div class="nx-ai-compose"><input class="nx-ai-input" id="nx-ai-input" placeholder="Ask Nexus AI anything…" autocomplete="off"><button class="nx-ai-voice" id="nx-ai-voice" title="Voice"><i class="fas fa-microphone"></i></button><button class="nx-ai-send" id="nx-ai-send" title="Send"><i class="fas fa-arrow-up"></i></button></div>
    </div>
    <button class="nx-ai-bubble" aria-label="Open Nexus AI"><span class="nx-ai-orb">N</span><span class="nx-ai-online"></span></button>`;
  document.body.appendChild(root);
  const msgs=root.querySelector('#nx-ai-messages'),input=root.querySelector('#nx-ai-input');
  const quick=['🎮 Find a PC','📅 Book a PC','🏆 Tournaments','🛒 Store','🍔 Order Food','🏅 Leaderboard','🆘 Support'];
  root.querySelector('#nx-ai-quick').innerHTML=quick.map(x=>`<button>${x}</button>`).join('');
  function add(text,who='ai'){const el=document.createElement('div');el.className='nx-ai-msg '+who;el.innerHTML=text;msgs.appendChild(el);msgs.scrollTop=msgs.scrollHeight;return el}
  function typing(){const el=document.createElement('div');el.className='nx-ai-msg ai nx-ai-typing';el.innerHTML='<i></i><i></i><i></i>';msgs.appendChild(el);msgs.scrollTop=msgs.scrollHeight;return el}
  function nav(hash){if(hash.startsWith('http')){location.href=hash;return} if(location.pathname.includes('/store/')){if(hash==='#store')return; location.href='../index.html'+hash}else{location.hash=hash}}
  function storeAction(text){
    if(!location.pathname.includes('/store/')) return false;
    if(/jersey|merch/i.test(text)){const el=document.querySelector('[data-category="Merch"]');if(el){el.click();document.getElementById('product-grid')?.scrollIntoView({behavior:'smooth'});return true}}
    if(/skin/i.test(text)){const el=document.querySelector('[data-category="Skins"]');if(el){el.click();document.getElementById('product-grid')?.scrollIntoView({behavior:'smooth'});return true}}
    if(/controller/i.test(text)){document.getElementById('store-search')?.focus();document.getElementById('store-search').value='controller';document.getElementById('store-search').dispatchEvent(new Event('input'));document.getElementById('product-grid')?.scrollIntoView({behavior:'smooth'});return true}
    return false;
  }
  function respond(raw){
    const t=raw.toLowerCase().trim();
    if(storeAction(t)) return 'Done — I filtered the Pro Store for you. The real product preview is ready to inspect.';
    if(/book|reserve|seat|pc for/i.test(t)){setTimeout(()=>nav('#booking'),350);return 'I can help with that. I’ve opened the booking area so you can choose the station and time. For live availability, the booking flow will use the connected café data.'}
    if(/leader|ranking|top player/i.test(t)){setTimeout(()=>nav('#leaderboards'),350);return 'Opening Arena Leaders — the live leaderboard section is now visible.'}
    if(/tournament|tourney|esport/i.test(t)){setTimeout(()=>nav('#tournaments'),350);return 'Opening the esports area. I can help you compare tournaments, formats, entry fees and registration once live data is connected.'}
    if(/store|shop|jersey|controller|skin|merch/i.test(t)){setTimeout(()=>nav('store/index.html'),350);return 'Opening the Pro Store. Ask me for jerseys, controllers, skins, bundles or a specific product.'}
    if(/food|burger|pizza|drink|cafe|hungry/i.test(t)){setTimeout(()=>nav('#cafe-menu'),350);return 'Opening Nexus Café. I can help you choose food and place an order through the connected POS flow.'}
    if(/wallet|balance|reward|xp|membership/i.test(t)){setTimeout(()=>document.getElementById('nav-login-btn')?.click(),350);return 'I can help with wallet, rewards and membership. I’ll keep private account information behind the authenticated profile.'}
    if(/help|support|problem|issue|fps|ping|crash|overheat/i.test(t)) return 'Tell me what is happening — for example “Valorant is not opening”, “FPS is low”, or “ping is high”. I’ll guide you through a safe diagnostic flow and escalate if needed.';
    if(/hi|hello|hey|bro|namaste/i.test(t)) return 'Hey! 👋 I’m Nexus AI. I can help with PCs, bookings, tournaments, the café, store, rewards, leaderboards and technical issues.';
    return 'I’m ready. Try: “find me a good PC”, “book a VIP PC”, “show jerseys”, “any tournament tonight?”, “order food”, or “my FPS is trash”.';
  }
  async function send(text){
    if(!text.trim())return;
    add(text,'user'); input.value=''; const wait=typing();
    try{
      const token=localStorage.getItem('nexusApiToken');
      const headers={'Content-Type':'application/json'}; if(token) headers.Authorization='Bearer '+token;
      const apiBase=window.NexusAPI?.base || `${window.location.protocol}//${window.location.hostname||'127.0.0.1'}:5000/api`;
      const res=await fetch(apiBase+'/chat',{method:'POST',headers,body:JSON.stringify({message:text,context})});
      const data=await res.json(); if(!res.ok) throw new Error(data.error||'Nexus AI backend unavailable');
      wait.remove(); add(data.reply);
    }catch(err){
      wait.remove(); add('Backend connection lost. I can still help with quick actions. Try the buttons above, or start the Python server and refresh.');
    }
  }
  add('Welcome to <b>Nexus AI</b> ⚡<div class="nx-ai-card"><b>Your Gaming Café Copilot</b><small>Bookings · PCs · Esports · Store · Café · Rewards · Support</small></div>');
  root.querySelector('.nx-ai-bubble').onclick=()=>{root.classList.toggle('open');if(root.classList.contains('open'))setTimeout(()=>input.focus(),100)};
  root.querySelector('.nx-ai-close').onclick=()=>root.classList.remove('open');
  root.querySelector('#nx-ai-send').onclick=()=>send(input.value);input.addEventListener('keydown',e=>{if(e.key==='Enter')send(input.value)});
  root.querySelectorAll('.nx-ai-quick button').forEach(b=>b.onclick=()=>send(b.textContent.replace(/^\S+\s/,'')));
  root.querySelector('#nx-ai-voice').onclick=()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){add('Voice input is not available in this browser. You can still type normally.');return}const r=new SR();r.lang='en-IN';r.onresult=e=>send(e.results[0][0].transcript);r.start();add('Listening… 🎙️');};
})();
