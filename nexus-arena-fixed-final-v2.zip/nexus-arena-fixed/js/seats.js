/* ============================================================
   NEXUS ARENA — LIVE SEATS JS (Local Frontend Edition)
   ============================================================ */

(function initSeats() {
  const statusLabels = { available: 'Available', busy: 'In Match', reserved: 'Reserved', maintenance: 'Maintenance' };
  let seatData = { pc: [], ps5: [], xbox: [], mobile: [], switch: [], vr: [] };

  function renderSection(containerId, seats) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    // Create short IDs like "P01" from "PC-01"
    const getShortId = (id) => {
      const parts = id.split('-');
      if (parts.length === 2) {
        if (parts[0] === 'PC') return 'P' + parts[1];
        if (parts[0] === 'PS5') return 'S' + parts[1];
        if (parts[0] === 'XBX') return 'X' + parts[1];
        if (parts[0] === 'MOB') return 'M' + parts[1];
        if (parts[0] === 'SW') return 'N' + parts[1];
        if (parts[0] === 'VR') return 'V' + parts[1];
        return parts[0].charAt(0) + parts[1];
      }
      return id;
    };

    container.innerHTML = seats.map(s => `
      <div class="seat-card ${s.status}" id="seat-${s.id.replace(/-/g,'')}">
        <span class="seat-name">${getShortId(s.id)}</span>
        <div class="seat-tooltip">ID: ${s.id} | ${statusLabels[s.status]}</div>
      </div>
    `).join('');
  }

  function renderAll() {
    renderSection('seats-pc',     seatData.pc);
    renderSection('seats-ps5',    seatData.ps5);
    renderSection('seats-xbox',   seatData.xbox);
    renderSection('seats-mobile', seatData.mobile);
    renderSection('seats-switch', seatData.switch);
    renderSection('seats-vr',     seatData.vr);
    updateSummary();
  }

  function updateSummary() {
    const all = Object.values(seatData).flat();
    const counts = { available: 0, busy: 0, reserved: 0, maintenance: 0 };
    all.forEach(s => counts[s.status]++);

    // Update active users
    const activeEl = document.getElementById('active-users-count');
    if (activeEl) {
      activeEl.textContent = counts.busy;
    }

    // Update capacity bars for each sector
    const sectors = [
      { id: 'pc', max: 50 },
      { id: 'ps5', max: 20 },
      { id: 'xbox', max: 10 },
      { id: 'mobile', max: 30 },
      { id: 'switch', max: 6 },
      { id: 'vr', max: 8 }
    ];

    sectors.forEach(sec => {
      const seats = seatData[sec.id] || [];
      // Occupied = busy + reserved
      const occupied = seats.filter(s => s.status === 'busy' || s.status === 'reserved').length;
      
      const countEl = document.getElementById(`cap-count-${sec.id}`);
      if (countEl) countEl.textContent = occupied;

      const fillEl = document.getElementById(`cap-fill-${sec.id}`);
      if (fillEl) {
        const percent = Math.min(100, Math.round((occupied / sec.max) * 100));
        fillEl.style.width = `${percent}%`;
      }
    });
  }

  // Load authoritative seat state from the Python API.
  async function loadSeatsFromAPI() {
    try {
      const data = await window.NexusAPI.request('/seats');
      seatData = { pc: [], ps5: [], xbox: [], mobile: [], switch: [], vr: [] };
      (data.seats || []).forEach(s => {
        const key = s.platform;
        if (seatData[key]) seatData[key].push({ id: s.id, status: s.status });
      });
      NexusDB.setSeats(seatData);
      renderAll();
    } catch (_) {
      const saved = NexusDB.getSeats();
      if (saved) {
        seatData = saved;
        renderAll();
      } else {
        const makeSeats=(prefix,count,platform)=>Array.from({length:count},(_,i)=>({id:`${prefix}-${String(i+1).padStart(2,'0')}`,status:'available'}));
        seatData={pc:makeSeats('PC',50,'pc'),ps5:makeSeats('PS5',20,'ps5'),xbox:makeSeats('XBX',10,'xbox'),mobile:makeSeats('MOB',30,'mobile'),switch:makeSeats('SW',6,'switch'),vr:makeSeats('VR',8,'vr')};
        NexusDB.setSeats(seatData); renderAll();
      }
    }
  }
  loadSeatsFromAPI();

  window.getSeatOptions = function(platform) {
    return (seatData[platform] || []).filter(s => s.status === 'available');
  };
})();
