/* NEXUS ARENA — live tournament registration + bracket UI */
(function () {
  const fallback = [
    {id:1,img:'images/store/tournament-pack.jpg',name:'Vanguard Protocol',game:'VALORANT',platform:'PC',prize:'₹1,50,000',entryFee:'₹500/Team',registered:0,maxTeams:32,endsAt:new Date(Date.now()+86400000).toISOString(),cardClass:'card-cyan',badgeClass:'badge-cyan'},
    {id:2,img:'images/store/team-pack.jpg',name:'Apex Predator Cup',game:'BGMI',platform:'Mobile',prize:'₹75,000',entryFee:'₹200/Team',registered:0,maxTeams:24,endsAt:new Date(Date.now()+172800000).toISOString(),cardClass:'card-gold',badgeClass:'badge-gold'},
    {id:3,img:'images/store/arena-pro-jersey.svg',name:'Iron Fist League',game:'FREE FIRE',platform:'Mobile',prize:'₹50,000',entryFee:'₹150/Team',registered:0,maxTeams:20,endsAt:new Date(Date.now()+259200000).toISOString(),cardClass:'card-orange',badgeClass:'badge-orange'},
    {id:4,img:'images/store/phantom-skin.svg',name:'Counter Strike Clash',game:'CS2',platform:'PC',prize:'₹1,00,000',entryFee:'₹400/Team',registered:0,maxTeams:32,endsAt:new Date(Date.now()+43200000).toISOString(),cardClass:'card-red',badgeClass:'badge-red'},
    {id:5,img:'images/store/nexus-hoodie.jpg',name:'Street Combat Pro',game:'TEKKEN 8',platform:'Console',prize:'₹30,000',entryFee:'₹100/Player',registered:0,maxTeams:16,endsAt:new Date(Date.now()+345600000).toISOString(),cardClass:'card-purple',badgeClass:'badge-purple'},
    {id:6,img:'images/store/xp-boost.jpg',name:'Galaxy Invaders VR',game:'VR ARENA',platform:'VR',prize:'₹25,000',entryFee:'₹250/Team',registered:0,maxTeams:8,endsAt:new Date(Date.now()+432000000).toISOString(),cardClass:'card-green',badgeClass:'badge-green'}
  ];
  let tournaments=[], activeFilter='All', timer;

  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const toast=(m,icon='ℹ️')=>window.showToast?window.showToast(m,icon):alert(m);
  const api=window.NexusAPI;
  const safeApi=()=>window.NexusAPI||{getToken:()=>false};

  function countdown(iso){let ms=new Date(iso)-Date.now();if(ms<0)ms=0;let d=Math.floor(ms/86400000);ms%=86400000;let h=Math.floor(ms/3600000);ms%=3600000;let m=Math.floor(ms/60000);let s=Math.floor(ms/1000)%60;return [d,h,m,s].map(x=>String(x).padStart(2,'0')).join(':');}
  async function load(){
    try{const d=await api.request('/tournaments');tournaments=d.tournaments.map((t,i)=>({...t, id:Number(t.id), registered:Number(t.registered||0), maxTeams:Number(t.maxTeams||fallback[i]?.maxTeams||16), endsAt:t.endsAt||fallback[i]?.endsAt, img:t.img||fallback[i]?.img, cardClass:fallback[i]?.cardClass||'card-cyan',badgeClass:fallback[i]?.badgeClass||'badge-cyan'}));}
    catch(e){tournaments=fallback.map(t=>({...t}))}
    render();
  }
  function render(){
    const grid=document.getElementById('tournaments-grid'); if(!grid)return;
    const old=grid.parentElement.querySelector('.t-filter-row'); if(old)old.remove();
    grid.insertAdjacentHTML('beforebegin',`<div class="t-filter-row">${['All','PC','Mobile','Console','VR'].map(f=>`<button class="t-filter-chip ${f===activeFilter?'active':''}" data-filter="${f}">${f}</button>`).join('')}</div>`);
    grid.parentElement.querySelectorAll('.t-filter-chip').forEach(b=>b.onclick=()=>{activeFilter=b.dataset.filter;render()});
    const list=tournaments.filter(t=>activeFilter==='All'||t.platform===activeFilter);
    grid.innerHTML=list.map(t=>{const full=t.registered>=t.maxTeams,pct=Math.min(100,t.registered/t.maxTeams*100);return `<div class="col-12 col-md-6 col-lg-4"><div class="t-clay-card ${t.cardClass}">
      <div class="t-card-img"><img src="${esc(t.img||fallback.find(x=>x.id===t.id)?.img||'images/store/tournament-pack.jpg')}" alt="${esc(t.name)}" loading="lazy"><div class="t-card-img-fade"></div><span class="t-game-badge ${t.badgeClass}"><span class="t-pulse-dot"></span>${esc(t.game)}</span></div>
      <div class="t-card-body"><h3 class="t-card-title">${esc(t.name)}</h3><div class="t-countdown-box"><span class="t-countdown-value" id="t-count-${t.id}">${countdown(t.endsAt)}</span></div>
      <div class="t-info-grid"><div class="t-info-box"><div class="t-info-label">Prize Pool</div><div class="t-info-value green">${esc(t.prize)}</div></div><div class="t-info-box"><div class="t-info-label">Entry Fee</div><div class="t-info-value white">${esc(t.entryFee)}</div></div></div>
      <div class="t-progress-wrap"><div class="t-progress-label"><span>Roster Fill</span><span id="t-reg-${t.id}">${t.registered}/${t.maxTeams} Squads</span></div><div class="t-progress-track"><div class="t-progress-fill" style="width:${pct}%"></div></div></div>
      <div class="t-card-actions"><button class="t-btn-register" ${full?'disabled':''} onclick="window.registerTournament(${t.id})">${full?'FULL':'JOIN OPS'}</button><button class="t-btn-bracket" onclick="window.viewBracket(${t.id})"><i class="fas fa-sitemap"></i> BRACKET</button></div></div></div></div>`}).join('');
  }
  function modal(id,html){document.getElementById(id)?.remove();document.body.insertAdjacentHTML('beforeend',`<div class="nx-action-modal open" id="${id}"><div class="nx-action-box">${html}</div></div>`);}
  window.registerTournament=async function(id){
    const t=tournaments.find(x=>x.id===id);if(!t)return;
    if(!safeApi().getToken()){toast('Please log in before tournament registration.','🔐');document.getElementById('nav-login-btn')?.click();return;}
    modal('tournament-register-modal',`<div class="nx-action-head"><div><h3>JOIN ${esc(t.name)}</h3><p>Enter your team and player roster.</p></div><button class="nx-close" onclick="document.getElementById('tournament-register-modal').remove()">✕</button></div>
      <div class="nx-form-grid"><div class="nx-field full"><label>Team Name *</label><input id="tr-team" maxlength="120" placeholder="Nexus Titans"></div>
      ${[1,2,3,4,5].map((n,i)=>`<div class="nx-field"><label>Player ${n}${i?'':' (Captain)'} ${i?'':'*'}</label><input id="tr-p${n}" maxlength="120" placeholder="Player ${n}"></div>`).join('')}</div>
      <div class="nx-actions"><button class="btn btn-ghost" onclick="document.getElementById('tournament-register-modal').remove()">Cancel</button><button class="btn btn-primary" id="tr-submit">Confirm Registration</button></div>`);
    const currentUser=safeApi().getUser?.(); if(currentUser?.username){document.getElementById('tr-p1').value=currentUser.username;}
    document.getElementById('tr-submit').onclick=async()=>{
      const team=document.getElementById('tr-team').value.trim(), players=[1,2,3,4,5].map(n=>document.getElementById('tr-p'+n).value.trim()).filter(Boolean);
      if(!team||!players.length){toast('Team name and captain are required.','⚠️');return}
      const btn=document.getElementById('tr-submit');btn.disabled=true;btn.textContent='REGISTERING…';
      try{const d=await api.request(`/tournaments/${id}/register`,{method:'POST',body:JSON.stringify({teamName:team,players})});Object.assign(t,d.tournament);document.getElementById('tournament-register-modal').remove();render();toast(`Registered ${team} successfully!`,'🏆');}
      catch(e){btn.disabled=false;btn.textContent='Confirm Registration';toast(e.message,'⚠️')}
    };
  };
  window.viewBracket=async function(id){
    const t=tournaments.find(x=>x.id===id);if(!t)return;
    try{const d=await api.request(`/tournaments/${id}/bracket`);const rows=d.matches.map(m=>`<div class="bracket-match"><b>Match ${m.match}</b><div>${esc(m.teamA||'TBD')}</div><div>${esc(m.teamB||'TBD')}</div><small>${m.status.toUpperCase()}</small></div>`).join('');modal('bracket-modal',`<div class="nx-action-head"><div><h3>${esc(t.name)} — BRACKET</h3><p>${d.teams.length} registered squads · Round 1</p></div><button class="nx-close" onclick="document.getElementById('bracket-modal').remove()">✕</button></div><div class="bracket-grid">${rows||'<p>No teams registered yet.</p>'}</div>`);}
    catch(e){toast(e.message,'⚠️')}
  };
  clearInterval(timer);timer=setInterval(()=>tournaments.forEach(t=>{const el=document.getElementById(`t-count-${t.id}`);if(el)el.textContent=countdown(t.endsAt)}),1000);
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',load);else load();
})();