/* ============================================================
   NEXUS ARENA — CAFE MENU, SHOP & CART JS
   ============================================================ */

const cart = { items: JSON.parse(localStorage.getItem('nexusCafeCart') || '[]'), total: 0 };

function updateCart() {
  cart.total = cart.items.reduce((acc, i) => acc + i.price * i.qty, 0); localStorage.setItem('nexusCafeCart', JSON.stringify(cart.items));
  const count = cart.items.reduce((acc, i) => acc + i.qty, 0);

  const floatBadge = document.getElementById('cart-float-badge');
  const drawerBadge = document.getElementById('cart-count-badge');
  const cartTotalAmount = document.getElementById('cart-total-amount');

  if (floatBadge) {
    if (count > 0) {
      floatBadge.style.display = 'flex';
      floatBadge.textContent = count > 9 ? '9+' : count;
    } else {
      floatBadge.style.display = 'none';
    }
  }

  if (drawerBadge) drawerBadge.textContent = count;
  if (cartTotalAmount) cartTotalAmount.innerHTML = '&#8377;' + cart.total.toLocaleString();
}

window.addToCart = function(name, price, img) {
  const existing = cart.items.find(i => i.name === name);
  if (existing) {
    existing.qty++;
  } else {
    cart.items.push({ name, price, qty: 1, img });
  }
  updateCart();
  renderCartItems();
  showToast(`${name} added to cart!`, '🛒');
  openCartDrawer();
};

window.removeFromCart = function(name) {
  const idx = cart.items.findIndex(i => i.name === name);
  if (idx > -1) {
    cart.items.splice(idx, 1);
    updateCart();
    renderCartItems();
  }
};

window.decreaseQty = function(name) {
  const item = cart.items.find(i => i.name === name);
  if (item) {
    item.qty--;
    if (item.qty <= 0) window.removeFromCart(name);
    else {
      updateCart();
      renderCartItems();
    }
  }
};

window.increaseQty = function(name) {
  const item = cart.items.find(i => i.name === name);
  if (item) {
    item.qty++;
    updateCart();
    renderCartItems();
  }
};

function renderCartItems() {
  const list = document.getElementById('cart-items-list');
  const btn = document.getElementById('cart-checkout-btn');
  if (!list) return;

  if (cart.items.length === 0) {
    list.innerHTML = `
      <div id="cart-empty-msg" style="text-align:center;padding:40px 20px;color:rgba(255,255,255,0.3);">
        <i class="fas fa-shopping-bag" style="font-size:3rem;display:block;margin-bottom:12px;"></i>
        Your cart is empty
      </div>`;
    if (btn) btn.disabled = true;
    return;
  }
  
  if (btn) btn.disabled = false;

  list.innerHTML = cart.items.map(item => `
    <div style="display:flex;align-items:center;gap:12px;padding:12px;background:rgba(255,255,255,0.03);border-radius:10px;border:1px solid rgba(255,255,255,0.05);">
      <div style="width:48px;height:48px;border-radius:8px;overflow:hidden;background:var(--bg-tertiary);flex-shrink:0;">
        <img src="${item.img}" alt="${item.name}" style="width:100%;height:100%;object-fit:cover;" onerror="this.style.display='none'">
      </div>
      <div style="flex:1;">
        <div style="font-family:var(--font-gaming);font-size:0.85rem;font-weight:700;color:#fff;">${item.name}</div>
        <div style="font-size:0.85rem;color:var(--neon-green);font-weight:700;">&#8377;${item.price}</div>
      </div>
      <div style="display:flex;align-items:center;gap:8px;background:rgba(0,0,0,0.3);border-radius:20px;padding:4px 8px;">
        <button onclick="decreaseQty('${item.name}')" style="background:none;border:none;color:rgba(255,255,255,0.6);cursor:pointer;font-size:0.9rem;">-</button>
        <span style="font-weight:700;font-size:0.85rem;color:#fff;width:12px;text-align:center;">${item.qty}</span>
        <button onclick="increaseQty('${item.name}')" style="background:none;border:none;color:rgba(255,255,255,0.6);cursor:pointer;font-size:0.9rem;">+</button>
      </div>
      <button onclick="removeFromCart('${item.name}')" style="background:none;border:none;color:var(--neon-pink);cursor:pointer;font-size:1rem;margin-left:8px;" title="Remove">×</button>
    </div>
  `).join('');
}

window.openCartDrawer = function() {
  document.getElementById('cart-drawer').style.right = '0';
  document.getElementById('cart-overlay').style.display = 'block';
  document.body.style.overflow = 'hidden';
  renderCartItems();
};

window.closeCartDrawer = function() {
  document.getElementById('cart-drawer').style.right = '-420px';
  document.getElementById('cart-overlay').style.display = 'none';
  document.body.style.overflow = '';
};

window.clearCart = function() {
  cart.items = [];
  updateCart();
  renderCartItems();
};

window.checkoutCart = async function() {
  if (cart.items.length === 0) return;
  if (!window.NexusAPI?.getToken()) { showToast('Please log in before ordering. 🔐', '⚠️'); document.getElementById('nav-login-btn')?.click(); return; }
  const user = window.NexusAPI.current() || {};
  const payload = {items: cart.items.map(i => ({id:'cafe-'+i.name.toLowerCase().replace(/\\s+/g,'-'), name:i.name, qty:i.qty, price:i.price})),
    total: cart.total, payment:'Café POS', name:user.username||'Nexus Player', phone:'N/A', email:user.email||''};
  try {
    const d = await window.NexusAPI.request('/orders', {method:'POST', body:JSON.stringify(payload)});
    cart.items=[]; updateCart(); closeCartDrawer();
    showToast(`Café order ${d.order.id} confirmed. 🍔`, '✅');
  } catch(e) { showToast(e.message || 'Could not place café order.', '⚠️'); }
};

// Replace viewCart with openCartDrawer globally if old code calls it
window.viewCart = window.openCartDrawer;


// ── CAFE CATEGORY TABS ─────────────────────────────────────────
(function initCafeTabs() {
  const tabs = document.querySelectorAll('[data-cafe-tab]');
  const cards = document.querySelectorAll('#cafe-grid .store-card');

  if (!tabs.length || !cards.length) return;

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      const filter = tab.dataset.cafeTab;
      cards.forEach(card => {
        if (filter === 'all' || card.dataset.category === filter) {
          card.style.display = 'flex';
          setTimeout(() => card.style.opacity = '1', 50);
        } else {
          card.style.opacity = '0';
          setTimeout(() => card.style.display = 'none', 300);
        }
      });
    });
  });
})();

// ── SHOP DATA ─────────────────────────────────────────────────
(function initShop() {
  const products = [
    { name: 'SteelSeries Apex Pro', brand: 'SteelSeries', price: 12999, old: 15999, emoji: '⌨️', discount: '19%', img: 'images/store/nexus-headset.jpg' },
    { name: 'Logitech G502 X Plus', brand: 'Logitech', price: 6499, old: 7999, emoji: '🖱️', discount: '19%', img: 'images/store/apex-pro-x.svg' },
    { name: 'HyperX Cloud III', brand: 'HyperX', price: 8499, old: 10999, emoji: '🎧', discount: '23%', img: 'images/store/nexus-headset.jpg' },
    { name: 'Nexus XL Mousepad', brand: 'NEXUS', price: 799, old: 1199, emoji: '🖱️', discount: '33%', img: '' },
    { name: 'Razer DeathAdder V3', brand: 'Razer', price: 5999, old: 7499, emoji: '🖱️', discount: '20%', img: '' },
    { name: 'NEXUS Hoodie', brand: 'NEXUS Merch', price: 1299, old: 1799, emoji: '👕', discount: '28%', img: '' },
    { name: 'Gaming Chair Pro', brand: 'AKRacing', price: 24999, old: 32000, emoji: '💺', discount: '22%', img: 'images/store/nexus-hoodie.jpg' },
    { name: 'NEXUS Gift Card', brand: 'NEXUS', price: 500, old: null, emoji: '🎁', discount: null, img: '' },
  ];

  const container = document.getElementById('shop-grid');
  if (!container) return;

  container.innerHTML = products.map(p => `
    <div class="shop-card">
      <div class="shop-img">
        ${p.discount ? `<div class="shop-discount">-${p.discount}</div>` : ''}
        ${p.img ? `<img src="${p.img}" alt="${p.name}" onerror="this.style.display='none'">` : `<span style="font-size:3.5rem;">${p.emoji}</span>`}
      </div>
      <div class="shop-body">
        <div class="shop-item-name">${p.name}</div>
        <div class="shop-brand">${p.brand}</div>
        <div class="shop-price-row">
          <div>
            <span class="shop-price">₹${p.price.toLocaleString()}</span>
            ${p.old ? `<span class="shop-price-old">₹${p.old.toLocaleString()}</span>` : ''}
          </div>
          <button class="btn btn-outline btn-sm" onclick="addToCart('${p.name}', ${p.price}, '${p.img}')">
            <i class="fas fa-shopping-bag"></i>
          </button>
        </div>
      </div>
    </div>
  `).join('');
})();
