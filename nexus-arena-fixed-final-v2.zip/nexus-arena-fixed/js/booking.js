/* ============================================================
   NEXUS ARENA — ENHANCED BOOKING JS (6-Step Flow)
   ============================================================ */

(function initBooking() {
  let currentStep = 1;
  let bookingData = { 
    platform: null, 
    date: null, 
    time: null, 
    seat: null, 
    duration: 1, 
    players: 1, 
    name: '',
    phone: '',
    game: '',
    requests: '',
    payment: null 
  };
  
  const prices = { pc: 80, ps5: 100, xbox: 90, mobile: 50, vr: 150, switch: 60 };
  const platformNames = { pc: 'Gaming PC', ps5: 'PlayStation 5', xbox: 'Xbox Series X', mobile: 'Mobile Booth', vr: 'VR Zone', switch: 'Nintendo Switch' };

  function getTotal() {
    return (prices[bookingData.platform] || 80) * (parseInt(bookingData.duration) || 1) * (parseInt(bookingData.players) || 1);
  }

  function updateLiveSummary() {
    const el = document.getElementById('booking-live-summary');
    if (!el) return;
    document.getElementById('bsum-platform').textContent = bookingData.platform ? platformNames[bookingData.platform] : '—';
    document.getElementById('bsum-seat').textContent = bookingData.seat || '—';
    document.getElementById('bsum-date').textContent = bookingData.date || '—';
    document.getElementById('bsum-time').textContent = bookingData.time || '—';
    document.getElementById('bsum-duration').textContent = bookingData.duration ? bookingData.duration + ' hr(s)' : '—';
    document.getElementById('bsum-players').textContent = bookingData.players || 1;
    document.getElementById('bsum-total').textContent = '₹' + getTotal();
  }

  function goToStep(step) {
    if (step < 1 || step > 6) return;
    
    // Validation before moving forward
    if (step > currentStep) {
      if (currentStep === 1 && !bookingData.platform) { showToast('Please select a gaming platform!', '⚠️'); return; }
      if (currentStep === 2) {
        bookingData.date = document.getElementById('book-date')?.value;
        bookingData.time = document.getElementById('book-time')?.value;
        if (!bookingData.date || !bookingData.time) { showToast('Please select Date & Time!', '⚠️'); return; }
        if (step === 3) generateVisualSeatMap();
      }
      if (currentStep === 3 && !bookingData.seat) { showToast('Please select a seat from the map!', '⚠️'); return; }
      if (currentStep === 4) {
        bookingData.duration = document.getElementById('book-duration')?.value || 1;
        bookingData.players = document.getElementById('book-players')?.value || 1;
      }
      if (currentStep === 5) {
        bookingData.name = document.getElementById('book-name')?.value.trim();
        bookingData.phone = document.getElementById('book-phone')?.value.trim();
        bookingData.game = document.getElementById('book-game')?.value.trim();
        bookingData.requests = document.getElementById('book-requests')?.value.trim();
        if (!bookingData.name || !bookingData.phone) { showToast('Name and Phone are required!', '⚠️'); return; }
      }
    }

    updateLiveSummary();

    // UI Updates for step transitions
    document.querySelectorAll('.step').forEach((s, i) => {
      s.classList.remove('active', 'done');
      if (i + 1 === step) s.classList.add('active');
      if (i + 1 < step)  s.classList.add('done');
    });
    document.querySelectorAll('.booking-step-content').forEach((c, i) => {
      c.classList.toggle('active', i + 1 === step);
    });
    currentStep = step;
    if (step === 6) buildFinalReview();
  }
  window.goToStep = goToStep;

  // Step 1: Platform Selection
  document.querySelectorAll('.platform-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.platform-btn').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      bookingData.platform = btn.dataset.platform;
      bookingData.seat = null; // reset seat when platform changes
      updateLiveSummary();
    });
  });

  // Step 3: Visual Seat Map Generation
  function generateVisualSeatMap() {
    const container = document.getElementById('seat-map-container');
    if (!container) return;
    
    // Clear old map
    container.innerHTML = '';
    
    // Generate dummy grid based on platform
    const platformStr = bookingData.platform || 'pc';
    const totalSeats = platformStr === 'vr' ? 8 : (platformStr === 'mobile' ? 30 : 20);
    const prefix = platformStr.toUpperCase() + '-';
    
    const grid = document.createElement('div');
    grid.style.display = 'grid';
    grid.style.gridTemplateColumns = 'repeat(auto-fill, minmax(60px, 1fr))';
    grid.style.gap = '12px';
    grid.style.padding = '10px';
    
    for (let i = 1; i <= totalSeats; i++) {
      const seatId = prefix + (i < 10 ? '0'+i : i);
      const btn = document.createElement('button');
      btn.className = 'v-seat-btn';
      
      // Randomly assign states for demo purposes
      let state = 'available';
      const rand = Math.random();
      if (rand > 0.85) state = 'booked';
      else if (rand > 0.75) state = 'reserved';
      else if (rand > 0.70) state = 'playing';
      else if (rand > 0.65) state = 'maintenance';
      
      btn.innerHTML = `<span style="font-size:0.7rem;font-weight:700;">${seatId}</span>`;
      btn.dataset.seatId = seatId;
      btn.dataset.state = state;
      
      // Style base on state
      btn.style.padding = '12px 8px';
      btn.style.borderRadius = '8px';
      btn.style.border = '1px solid rgba(255,255,255,0.1)';
      btn.style.color = '#fff';
      btn.style.cursor = state === 'available' ? 'pointer' : 'not-allowed';
      btn.style.transition = 'all 0.2s';
      
      if (state === 'available') {
        btn.style.background = 'rgba(0, 255, 136, 0.1)';
        btn.style.borderColor = 'rgba(0, 255, 136, 0.3)';
        if (bookingData.seat === seatId) {
          btn.style.background = 'rgba(0, 255, 136, 0.4)';
          btn.style.borderColor = '#00ff88';
          btn.style.boxShadow = '0 0 12px rgba(0,255,136,0.4)';
        }
      } else if (state === 'booked') {
        btn.style.background = 'rgba(255, 0, 110, 0.2)';
        btn.style.borderColor = 'rgba(255, 0, 110, 0.4)';
        btn.style.opacity = '0.6';
      } else if (state === 'reserved') {
        btn.style.background = 'rgba(255, 107, 0, 0.2)';
        btn.style.borderColor = 'rgba(255, 107, 0, 0.4)';
      } else if (state === 'playing') {
        btn.style.background = 'rgba(124, 58, 237, 0.2)';
        btn.style.borderColor = 'rgba(124, 58, 237, 0.4)';
      } else if (state === 'maintenance') {
        btn.style.background = 'rgba(85, 85, 85, 0.4)';
        btn.style.borderColor = '#555';
        btn.style.opacity = '0.5';
      }

      if (state === 'available') {
        btn.onclick = () => {
          bookingData.seat = seatId;
          updateLiveSummary();
          generateVisualSeatMap(); // re-render to highlight selected
        };
        btn.onmouseover = () => { if(bookingData.seat !== seatId) btn.style.background = 'rgba(0, 255, 136, 0.2)'; };
        btn.onmouseout = () => { if(bookingData.seat !== seatId) btn.style.background = 'rgba(0, 255, 136, 0.1)'; };
      }
      
      grid.appendChild(btn);
    }
    
    container.appendChild(grid);
  }

  // Step 6: Payment Methods
  document.querySelectorAll('.pay-method').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.pay-method').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      bookingData.payment = btn.dataset.payment;
      const detail = document.getElementById('booking-payment-detail');
      if (detail) {
        const total = '₹' + getTotal();
        detail.innerHTML = {
          upi: `<strong>UPI PAYMENT</strong><br>Open your UPI app and pay <strong>${total}</strong>. A demo UPI reference will be generated on confirmation.`,
          card: `<strong>CARD PAYMENT</strong><br>Use a PCI-compliant payment gateway in production. Demo checkout will validate the selection before creating the booking.`,
          wallet: `<strong>NEXUS WALLET</strong><br>Your wallet balance will be checked before deduction. Amount due: <strong>${total}</strong>.`,
          netbanking: `<strong>NET BANKING</strong><br>Select your bank in the next payment screen. Amount due: <strong>${total}</strong>.`
        }[bookingData.payment];
      }
    });
  });

  function row(label, value) {
    return `<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.05);"><span style="font-family:var(--font-accent);font-size:0.82rem;color:rgba(255,255,255,0.45);text-transform:uppercase;letter-spacing:0.08em;">${label}</span><span style="font-family:var(--font-gaming);font-size:0.9rem;font-weight:700;color:#fff;">${value}</span></div>`;
  }

  function buildFinalReview() {
    const el = document.getElementById('booking-summary');
    if (!el) return;
    el.innerHTML = `
      <div style="background:rgba(0,212,255,0.05);border:1px solid rgba(0,212,255,0.2);border-radius:16px;padding:24px;">
        <div style="display:grid;gap:8px;">
          ${row('Name', bookingData.name)}
          ${row('Phone', bookingData.phone)}
          ${row('Game', bookingData.game || 'Not specified')}
          ${row('Payment', bookingData.payment ? bookingData.payment.toUpperCase() : 'Not selected')}
          ${row('Total', '₹' + getTotal())}
        </div>
        <p style="font-size:0.8rem;color:rgba(255,255,255,0.4);margin-top:16px;font-style:italic;">Please review the summary panel on the right before paying.</p>
      </div>
    `;
  }

  // Confirm Booking — Python API
  window.confirmBooking = async function() {
    if (!bookingData.payment) { showToast('Please select a payment method!', '⚠️'); return; }
    if (!window.NexusAPI?.getToken()) { showToast('Please log in before confirming a booking.', '🔐'); return; }
    const payload = { ...bookingData, total: getTotal() };
    try {
      const data = await window.NexusAPI.request('/bookings', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
      const confirmed = data.booking;
      window.NexusAPI.setUser(data.user);
      window.NexusAuth.notify();

      const successId = confirmed.id;
      const el = document.getElementById('booking-success');
      if (el) {
        el.style.display = 'block';
        el.innerHTML = `
          <div style="text-align:center;padding:40px 20px;">
            <div style="font-size:4rem;margin-bottom:20px;animation:bounce 1s infinite;">✅</div>
            <h2 style="font-family:var(--font-gaming);font-size:1.8rem;background:linear-gradient(135deg,var(--neon-cyan),var(--neon-green));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;margin-bottom:12px;">Booking Confirmed!</h2>
            <p style="color:rgba(255,255,255,0.6);font-family:var(--font-accent);margin-bottom:24px;">Your gaming session has been reserved successfully.</p>
            <div style="background:rgba(0,0,0,0.3);border-radius:16px;padding:20px;margin-bottom:24px;display:inline-block;min-width:200px;">
              <div style="font-family:var(--font-gaming);font-size:2.5rem;font-weight:900;color:var(--neon-cyan);letter-spacing:0.3em;">#${successId}</div>
              <div style="font-size:0.75rem;color:rgba(255,255,255,0.4);font-family:var(--font-accent);margin-top:4px;">BOOKING ID</div>
            </div>
            <p style="color:rgba(255,255,255,0.5);font-size:0.85rem;font-family:var(--font-body);">Booking saved securely to your account.</p>
            <button class="btn btn-primary mt-3" onclick="resetBooking()">Book Another Session</button>
          </div>
        `;
        document.querySelectorAll('.booking-step-content').forEach(c => c.classList.remove('active'));
        document.querySelector('.booking-steps').style.display = 'none';
        const liveSum = document.getElementById('booking-live-summary');
        if (liveSum) liveSum.style.display = 'none';
      }
      showToast('Booking confirmed and saved! 🎮', '✅');
    } catch (err) {
      showToast(err.message, '❌');
    }
  };

  window.resetBooking = function() {
    bookingData = { platform: null, date: null, time: null, seat: null, duration: 1, players: 1, name: '', phone: '', game: '', requests: '', payment: null };
    currentStep = 1;
    const el = document.getElementById('booking-success');
    if (el) el.style.display = 'none';
    document.querySelector('.booking-steps').style.display = 'flex';
    const liveSum = document.getElementById('booking-live-summary');
    if (liveSum) liveSum.style.display = 'block';
    
    document.querySelectorAll('.platform-btn').forEach(b => b.classList.remove('selected'));
    document.querySelectorAll('.pay-method').forEach(b => b.classList.remove('selected'));
    updateLiveSummary();
    goToStep(1);
  };

  // Add event listeners to input fields to trigger live summary update
  ['book-date', 'book-time', 'book-duration', 'book-players'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', (e) => {
      bookingData[id.replace('book-')] = e.target.value;
      updateLiveSummary();
    });
  });

  const datePicker = document.getElementById('book-date');
  if (datePicker) { datePicker.min = new Date().toISOString().split('T')[0]; }
})();
