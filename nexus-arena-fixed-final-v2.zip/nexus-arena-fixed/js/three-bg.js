/* ============================================================
   NEXUS ARENA — THREE.JS HERO BACKGROUND
   ============================================================ */

(function initThreeBackground() {
  const canvas = document.getElementById('hero-canvas');
  if (!canvas) return;

  // Wait for THREE to load
  function tryInit() {
    if (typeof THREE === 'undefined') {
      setTimeout(tryInit, 100);
      return;
    }
    startScene();
  }

  function startScene() {
    const W = window.innerWidth;
    const H = window.innerHeight;

    // Scene
    const scene    = new THREE.Scene();
    const camera   = new THREE.PerspectiveCamera(75, W / H, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });

    renderer.setSize(W, H);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    camera.position.z = 5;

    // ── STAR PARTICLES ───────────────────────────────────────
    const starCount = 2500;
    const starGeo   = new THREE.BufferGeometry();
    const starPos   = new Float32Array(starCount * 3);
    const starColors = new Float32Array(starCount * 3);

    const colors = [
      [0, 0.83, 1],     // neon cyan
      [0.49, 0.23, 0.93], // neon purple
      [1, 0, 0.43],     // neon pink
      [1, 1, 1],         // white
    ];

    for (let i = 0; i < starCount; i++) {
      starPos[i * 3]     = (Math.random() - 0.5) * 100;
      starPos[i * 3 + 1] = (Math.random() - 0.5) * 100;
      starPos[i * 3 + 2] = (Math.random() - 0.5) * 100;

      const c = colors[Math.floor(Math.random() * colors.length)];
      starColors[i * 3]     = c[0];
      starColors[i * 3 + 1] = c[1];
      starColors[i * 3 + 2] = c[2];
    }

    starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    starGeo.setAttribute('color',    new THREE.BufferAttribute(starColors, 3));

    const starMat = new THREE.PointsMaterial({
      size: 0.15,
      vertexColors: true,
      transparent: true,
      opacity: 0.8,
      sizeAttenuation: true,
    });

    const stars = new THREE.Points(starGeo, starMat);
    scene.add(stars);

    // ── FLOATING GEOMETRY ────────────────────────────────────
    const geometries = [];

    function createFloater(geoType, color, x, y, z, scale = 1) {
      let geo;
      switch (geoType) {
        case 'icosa': geo = new THREE.IcosahedronGeometry(0.3 * scale, 0); break;
        case 'octa':  geo = new THREE.OctahedronGeometry(0.25 * scale, 0); break;
        case 'torus': geo = new THREE.TorusGeometry(0.2 * scale, 0.08, 8, 16); break;
        case 'tetra': geo = new THREE.TetrahedronGeometry(0.3 * scale, 0); break;
        default: geo = new THREE.BoxGeometry(0.3 * scale, 0.3 * scale, 0.3 * scale);
      }

      const mat = new THREE.MeshBasicMaterial({
        color,
        wireframe: true,
        transparent: true,
        opacity: 0.25,
      });

      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(x, y, z);
      mesh.userData = {
        rotX: (Math.random() - 0.5) * 0.02,
        rotY: (Math.random() - 0.5) * 0.02,
        rotZ: (Math.random() - 0.5) * 0.02,
        floatY: Math.random() * Math.PI * 2,
        floatSpeed: 0.005 + Math.random() * 0.01,
        baseY: y,
      };
      scene.add(mesh);
      geometries.push(mesh);
      return mesh;
    }

    const floaterData = [
      ['icosa', 0x00d4ff, -4,  1.5, -2, 1.5],
      ['octa',  0x7c3aed,  4, -1,   -3, 1.2],
      ['torus', 0xff006e, -3, -2,   -1, 1.8],
      ['tetra', 0x00d4ff,  3,  2,   -2, 1.0],
      ['icosa', 0x7c3aed,  0, -3,   -2, 0.8],
      ['octa',  0xff006e, -5, 0,    -3, 1.0],
      ['torus', 0x00d4ff,  5, 1,    -4, 1.4],
      ['tetra', 0x7c3aed, -2, 3,    -3, 0.9],
    ];

    floaterData.forEach(d => createFloater(...d));

    // ── GRID PLANE ───────────────────────────────────────────
    const gridHelper = new THREE.GridHelper(30, 30, 0x00d4ff, 0x001a2e);
    gridHelper.position.y = -3;
    gridHelper.material.opacity = 0.15;
    gridHelper.material.transparent = true;
    scene.add(gridHelper);

    // ── MOUSE PARALLAX ───────────────────────────────────────
    let mouseX = 0, mouseY = 0;
    document.addEventListener('mousemove', e => {
      mouseX = (e.clientX / window.innerWidth  - 0.5) * 2;
      mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
    });

    // ── ANIMATE ──────────────────────────────────────────────
    let time = 0;
    function animate() {
      requestAnimationFrame(animate);
      time += 0.005;

      // Rotate stars slowly
      stars.rotation.x += 0.0001;
      stars.rotation.y += 0.0002;

      // Mouse parallax on camera
      camera.position.x += (mouseX * 1.5 - camera.position.x) * 0.03;
      camera.position.y += (-mouseY * 1.5 - camera.position.y) * 0.03;
      camera.lookAt(scene.position);

      // Rotate floaters
      geometries.forEach(mesh => {
        mesh.rotation.x += mesh.userData.rotX;
        mesh.rotation.y += mesh.userData.rotY;
        mesh.rotation.z += mesh.userData.rotZ;
        mesh.userData.floatY += mesh.userData.floatSpeed;
        mesh.position.y = mesh.userData.baseY + Math.sin(mesh.userData.floatY) * 0.3;
      });

      // Pulse star opacity
      starMat.opacity = 0.6 + Math.sin(time * 2) * 0.15;

      renderer.render(scene, camera);
    }

    animate();

    // ── RESIZE ───────────────────────────────────────────────
    window.addEventListener('resize', () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    });
  }

  tryInit();
})();
