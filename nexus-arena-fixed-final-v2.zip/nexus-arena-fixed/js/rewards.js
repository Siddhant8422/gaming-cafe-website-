/* NEXUS ARENA — LOCAL REWARD SPIN */
(function(){
  const segments=[
    {label:'50 XP',color:'#00d4ff',glow:'rgba(0,212,255,.6)'},{label:'100 XP',color:'#00ff88',glow:'rgba(0,255,136,.6)'},
    {label:'₹100 OFF',color:'#ff006e',glow:'rgba(255,0,110,.6)'},{label:'250 XP',color:'#b026ff',glow:'rgba(176,38,255,.6)'},
    {label:'FREE HOUR',color:'#ffd700',glow:'rgba(255,215,0,.6)'},{label:'75 XP',color:'#00a8ff',glow:'rgba(0,168,255,.6)'},
    {label:'150 XP',color:'#7c3aed',glow:'rgba(124,58,237,.6)'},{label:'₹200 OFF',color:'#ff4f82',glow:'rgba(255,79,130,.6)'}
  ];
  const cooldown=86400000;let canvas,ctx,angle=0,spinning=false;
  function setup(){canvas=document.getElementById('spin-canvas');if(!canvas)return false;ctx=canvas.getContext('2d');draw();return true}
  function draw(a=angle){if(!ctx)return;const size=260,cx=130,cy=130,r=116,arc=Math.PI*2/segments.length;ctx.clearRect(0,0,size,size);segments.forEach((s,i)=>{const st=a+i*arc,en=st+arc,mid=st+arc/2;ctx.beginPath();ctx.moveTo(cx,cy);ctx.arc(cx,cy,r,st,en);ctx.closePath();ctx.fillStyle=s.color;ctx.fill();ctx.strokeStyle='rgba(0,0,0,.5)';ctx.lineWidth=2;ctx.stroke();ctx.save();ctx.translate(cx,cy);ctx.rotate(mid);ctx.textAlign='right';ctx.fillStyle='#fff';ctx.font='bold 12px Orbitron,monospace';ctx.shadowColor='#000';ctx.shadowBlur=4;ctx.fillText(s.label,r-8,4);ctx.restore()});ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.strokeStyle='rgba(0,212,255,.8)';ctx.lineWidth=3;ctx.shadowColor='rgba(0,212,255,.8)';ctx.shadowBlur=16;ctx.stroke();ctx.shadowBlur=0}
  function fmt(ms){const t=Math.ceil(ms/1000),h=Math.floor(t/3600),m=Math.floor(t%3600/60),s=t%60;return `${String(h).padStart(2,'0')}h ${String(m).padStart(2,'0')}m ${String(s).padStart(2,'0')}s`}
  function update(last){const btn=document.getElementById('spin-btn'),status=document.getElementById('reward-last-spin'),cd=document.getElementById('spin-cooldown'),rem=Math.max(0,cooldown-(Date.now()-(last||0))),ready=!last||rem===0;if(btn){btn.disabled=spinning||!ready;btn.innerHTML=ready?'<i class="fas fa-dice"></i> SPIN NOW':'<i class="fas fa-clock"></i> 24H COOLDOWN'}if(status)status.textContent=ready?'Ready':'Cooldown';if(cd)cd.textContent=ready?'Your free spin is ready.':'Next spin in '+fmt(rem);if(!ready)setTimeout(()=>update(last),1000)}
  async function state() {
    if (!window.NexusAPI?.getToken()) return {};
    try { return await window.NexusAPI.request('/rewards'); }
    catch (_) { return {}; }
  }
  async function load() {
    setup();
    const u = NexusAPI.current();
    if (!u) { update(null); renderBirthday({}); return; }
    const r = await state();
    update(r.lastSpinAt ? new Date(r.lastSpinAt).getTime() : null);
    renderBirthday({ ...u, ...(r.user || {}) });
  }
  window.updateRewardProfile = async function(user) {
    setup();
    const r = await state();
    update(r.lastSpinAt ? new Date(r.lastSpinAt).getTime() : null);
    renderBirthday({ ...user, ...(r.user || {}) });
  };
  window.spinWheel = async function() {
    if (spinning) return;
    if (!NexusAPI?.getToken()) { showToast('Please log in to use your daily reward spin.', '🔐'); return; }
    spinning = true;
    const btn = document.getElementById('spin-btn');
    if (btn) btn.disabled = true;
    try {
      const data = await NexusAPI.request('/rewards/spin', { method: 'POST' });
      const winner = data.prize;
      const idx = segments.findIndex(s => s.label === winner.label);
      const safeIdx = idx >= 0 ? idx : 0;
      const arc = Math.PI * 2 / segments.length;
      const full = (5 + Math.floor(Math.random() * 4)) * Math.PI * 2;
      const mid = safeIdx * arc + arc / 2;
      const target = -mid - Math.PI / 2;
      let delta = (target - angle) % (Math.PI * 2);
      if (delta <= 0) delta += Math.PI * 2;
      const total = full + delta, startAngle = angle, start = performance.now(), dur = 4200;
      function anim(now) {
        const p = Math.min(1, (now - start) / dur), ease = 1 - Math.pow(1 - p, 4);
        angle = startAngle + total * ease; draw();
        if (p < 1) requestAnimationFrame(anim);
        else {
          spinning = false;
          const out = document.getElementById('spin-result');
          if (out) out.innerHTML = `<div class="spin-win-banner" style="--win-color:${segments[safeIdx].color};--win-glow:${segments[safeIdx].glow};"><div class="spin-win-icon">🎉</div><div class="spin-win-label">YOU WON!</div><div class="spin-win-prize">${winner.label}</div></div>`;
          NexusAPI.setUser(data.user);
          window.NexusAuth.notify();
          showToast(`🎉 You won: ${winner.label}!`, '🎰');
          update(new Date(data.lastSpinAt).getTime());
        }
      }
      requestAnimationFrame(anim);
    } catch (err) {
      spinning = false;
      showToast(err.message, '❌');
      if (btn) btn.disabled = false;
    }
  };
  window.verifyBirthday = async function() {
    const input = document.getElementById('birthday-verify-date');
    if (!NexusAPI?.getToken() || !input?.value) { showToast('Log in and enter your registered birthday first.', '🔐'); return; }
    try {
      const data = await NexusAPI.request('/birthday/verify', {
        method: 'POST', body: JSON.stringify({ birthday: input.value })
      });
      NexusAPI.setUser(data.user);
      NexusAuth.notify();
      showToast('Birthday verified successfully! 🎂', '🛡️');
      renderBirthday(data.user);
    } catch (err) { showToast(err.message, '❌'); }
  };
  window.claimBirthdayGift = async function() {
    if (!NexusAPI?.getToken()) return;
    try {
      const data = await NexusAPI.request('/birthday/claim', { method: 'POST' });
      NexusAPI.setUser(data.user);
      NexusAuth.notify();
      showToast('Happy Birthday! Your gift has been added. 🎉', '🎂');
      renderBirthday(data.user);
    } catch (err) { showToast(err.message, '❌'); }
  };
  document.addEventListener('click',e=>{if(e.target.closest('[data-dash-tab="rewards"]'))setTimeout(load,50)});window.addEventListener('load',load);
})();
