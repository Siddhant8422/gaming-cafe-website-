/* NEXUS ARENA — PYTHON API COMPATIBILITY LAYER
   Non-critical UI state such as wishlist/cart remains browser-local.
   Account, bookings, orders, rewards and birthday state live in the Python API. */
(function () {
  const KEYS = {
    session: 'nexusApiToken',
    user: 'nexusApiUser',
    seats: 'nexusSeatState',
    wishlist: 'nexusWishlist'
  };

  const read = (k, fallback) => {
    try {
      const v = localStorage.getItem(k);
      return v ? JSON.parse(v) : fallback;
    } catch (_) { return fallback; }
  };
  const write = (k, v) => localStorage.setItem(k, JSON.stringify(v));

  window.NexusDB = {
    keys: KEYS,
    current: () => window.NexusAPI ? window.NexusAPI.current() : read(KEYS.user, null),
    updateUser: (patch) => {
      const current = read(KEYS.user, null);
      const updated = current ? { ...current, ...patch } : null;
      if (updated) write(KEYS.user, updated);
      return updated;
    },
    getSeats: () => read(KEYS.seats, null),
    setSeats: (v) => { write(KEYS.seats, v); return v; }
  };

  window.NexusAuth = {
    currentUser: () => window.NexusAPI ? window.NexusAPI.current() : read(KEYS.user, null),
    onChange(fn) {
      fn(this.currentUser());
      window.addEventListener('nexus-auth-changed', () => fn(this.currentUser()));
    },
    notify() { window.dispatchEvent(new Event('nexus-auth-changed')); }
  };
})();
