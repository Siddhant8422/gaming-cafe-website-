import os
import uuid
import random
from datetime import datetime, timezone, timedelta
from functools import wraps

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import (
    JWTManager, create_access_token, get_jwt_identity, jwt_required
)
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "nexus_arena.db")

app = Flask(__name__, static_folder=BASE_DIR, static_url_path="")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + DB_PATH
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["JWT_SECRET_KEY"] = os.environ.get(
    "NEXUS_JWT_SECRET", "CHANGE_THIS_SECRET_IN_PRODUCTION"
)
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=12)

db = SQLAlchemy(app)
jwt = JWTManager(app)
CORS(app, resources={r"/api/*": {"origins": "*"}})

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uid = db.Column(db.String(64), unique=True, nullable=False, index=True)
    username = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    birthday = db.Column(db.String(10), nullable=True)
    birthday_verified = db.Column(db.Boolean, default=False, nullable=False)
    birthday_verified_at = db.Column(db.DateTime, nullable=True)
    birthday_gift_claimed_year = db.Column(db.Integer, default=0, nullable=False)
    birthday_gift = db.Column(db.String(255), nullable=True)
    level = db.Column(db.Integer, default=1, nullable=False)
    xp = db.Column(db.Integer, default=0, nullable=False)
    wallet = db.Column(db.Integer, default=0, nullable=False)
    membership = db.Column(db.String(40), default="NONE", nullable=False)
    total_hours = db.Column(db.Integer, default=0, nullable=False)
    wins = db.Column(db.Integer, default=0, nullable=False)
    points = db.Column(db.Integer, default=0, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.String(32), unique=True, nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    platform = db.Column(db.String(30), nullable=False)
    date = db.Column(db.String(10), nullable=False)
    time = db.Column(db.String(20), nullable=False)
    seat = db.Column(db.String(30), nullable=False)
    duration = db.Column(db.Integer, default=1, nullable=False)
    players = db.Column(db.Integer, default=1, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(30), nullable=False)
    game = db.Column(db.String(120), nullable=True)
    requests = db.Column(db.Text, nullable=True)
    payment = db.Column(db.String(30), nullable=False)
    total = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(30), default="confirmed", nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.String(32), unique=True, nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    items_json = db.Column(db.Text, nullable=False)
    total = db.Column(db.Integer, nullable=False)
    payment = db.Column(db.String(30), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(30), nullable=False)
    email = db.Column(db.String(255), nullable=False)
    status = db.Column(db.String(30), default="confirmed", nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

class RewardState(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), unique=True, nullable=False, index=True)
    last_spin_at = db.Column(db.DateTime, nullable=True)

class Seat(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    seat_id = db.Column(db.String(30), unique=True, nullable=False, index=True)
    platform = db.Column(db.String(30), nullable=False)
    status = db.Column(db.String(30), default="available", nullable=False)
    current_user = db.Column(db.String(64), nullable=True)
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

def now_utc():
    return datetime.now(timezone.utc)

def iso(dt):
    return dt.isoformat() if dt else None

def user_payload(u):
    level = max(1, (u.xp // 1000) + 1)
    return {
        "uid": u.uid,
        "username": u.username,
        "email": u.email,
        "birthday": u.birthday,
        "birthdayVerified": bool(u.birthday_verified),
        "birthdayVerifiedAt": iso(u.birthday_verified_at),
        "birthdayGiftClaimedYear": u.birthday_gift_claimed_year or 0,
        "birthdayGift": u.birthday_gift,
        "level": level,
        "xp": u.xp,
        "xpNext": level * 1000,
        "rank": "N/A",
        "wallet": u.wallet,
        "membership": u.membership,
        "totalHours": u.total_hours,
        "wins": u.wins,
        "points": u.points,
        "createdAt": iso(u.created_at),
    }

def get_current_user():
    uid = get_jwt_identity()
    return User.query.filter_by(uid=uid).first()

def error(message, status=400):
    return jsonify({"error": message}), status

def valid_required(data, fields):
    return all(str(data.get(f, "")).strip() for f in fields)

def calculate_level(xp):
    return max(1, xp // 1000 + 1)

def booking_payload(b):
    return {
        "id": b.booking_id,
        "platform": b.platform,
        "date": b.date,
        "time": b.time,
        "seat": b.seat,
        "duration": b.duration,
        "players": b.players,
        "name": b.name,
        "phone": b.phone,
        "game": b.game or "",
        "requests": b.requests or "",
        "payment": b.payment,
        "total": b.total,
        "status": b.status,
        "createdAt": iso(b.created_at),
    }

def order_payload(o):
    import json
    return {
        "id": o.order_id,
        "items": json.loads(o.items_json),
        "total": o.total,
        "payment": o.payment,
        "name": o.name,
        "phone": o.phone,
        "email": o.email,
        "status": o.status,
        "createdAt": iso(o.created_at),
    }

def seed_seats():
    if Seat.query.count():
        return
    definitions = [
        ("PC", 50, "pc"), ("PS5", 20, "ps5"), ("XBX", 10, "xbox"),
        ("MOB", 30, "mobile"), ("SW", 6, "switch"), ("VR", 8, "vr")
    ]
    for prefix, count, platform in definitions:
        for i in range(1, count + 1):
            seat_id = f"{prefix}-{i:02d}"
            status = "available"
            # Keep the same style of realistic demo availability as the UI.
            r = (i * 17 + len(platform) * 7) % 100
            if r > 91:
                status = "maintenance"
            elif r > 79:
                status = "reserved"
            elif r > 57:
                status = "busy"
            db.session.add(Seat(
                seat_id=seat_id, platform=platform, status=status,
                updated_at=now_utc()
            ))
    db.session.commit()

@app.get("/api/health")
def health():
    return jsonify({"ok": True, "service": "NEXUS ARENA API"})

@app.post("/api/auth/register")
def register():
    data = request.get_json(silent=True) or {}
    if not valid_required(data, ["username", "email", "password"]):
        return error("Username, email and password are required.")
    username = str(data["username"]).strip()
    email = str(data["email"]).strip().lower()
    password = str(data["password"])
    birthday = str(data.get("birthday", "")).strip() or None
    if len(username) < 3:
        return error("Username must be at least 3 characters.")
    if len(password) < 6:
        return error("Password must be at least 6 characters.")
    if "@" not in email or "." not in email.split("@")[-1]:
        return error("Enter a valid email address.")
    if User.query.filter_by(email=email).first():
        return error("An account with this email already exists.", 409)
    if User.query.filter_by(username=username).first():
        return error("That username is already taken.", 409)

    u = User(
        uid="usr-" + uuid.uuid4().hex,
        username=username,
        email=email,
        password_hash=generate_password_hash(password),
        birthday=birthday,
    )
    db.session.add(u)
    db.session.flush()
    db.session.add(RewardState(user_id=u.id))
    db.session.commit()
    token = create_access_token(identity=u.uid)
    return jsonify({"token": token, "user": user_payload(u)}), 201

@app.post("/api/auth/login")
def login():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))
    u = User.query.filter_by(email=email).first()
    if not u or not check_password_hash(u.password_hash, password):
        return error("Invalid email or password.", 401)
    token = create_access_token(identity=u.uid)
    return jsonify({"token": token, "user": user_payload(u)})

@app.get("/api/auth/me")
@jwt_required()
def me():
    u = get_current_user()
    if not u:
        return error("User account not found.", 404)
    return jsonify({"user": user_payload(u)})

@app.post("/api/auth/logout")
@jwt_required()
def logout():
    # JWTs are short-lived and the browser removes its token on logout.
    return jsonify({"ok": True})

@app.get("/api/dashboard")
@jwt_required()
def dashboard():
    u = get_current_user()
    if not u:
        return error("User account not found.", 404)
    bookings = Booking.query.filter_by(user_id=u.id).order_by(Booking.created_at.desc()).limit(10).all()
    orders = Order.query.filter_by(user_id=u.id).order_by(Order.created_at.desc()).limit(10).all()
    return jsonify({
        "user": user_payload(u),
        "bookings": [booking_payload(b) for b in bookings],
        "orders": [order_payload(o) for o in orders],
    })

@app.get("/api/bookings")
@jwt_required()
def list_bookings():
    u = get_current_user()
    bookings = Booking.query.filter_by(user_id=u.id).order_by(Booking.created_at.desc()).all()
    return jsonify({"bookings": [booking_payload(b) for b in bookings]})

@app.post("/api/bookings")
@jwt_required()
def create_booking():
    u = get_current_user()
    data = request.get_json(silent=True) or {}
    fields = ["platform", "date", "time", "seat", "duration", "players", "name", "phone", "payment", "total"]
    if not valid_required(data, fields):
        return error("Complete all required booking fields.")
    try:
        duration = int(data["duration"])
        players = int(data["players"])
        total = int(data["total"])
    except (TypeError, ValueError):
        return error("Invalid booking numbers.")
    if duration < 1 or duration > 24:
        return error("Duration must be between 1 and 24 hours.")
    if players < 1 or players > 10:
        return error("Players must be between 1 and 10.")
    if total < 0:
        return error("Invalid booking total.")

    seat_id = str(data["seat"]).strip()
    seat = Seat.query.filter_by(seat_id=seat_id).with_for_update().first()
    if not seat:
        return error("Selected seat does not exist.", 404)
    if seat.status not in ("available",):
        return error("That seat is no longer available. Please choose another seat.", 409)

    booking_id = "NX" + uuid.uuid4().hex[:8].upper()
    b = Booking(
        booking_id=booking_id, user_id=u.id,
        platform=str(data["platform"]).strip().lower(),
        date=str(data["date"]).strip(), time=str(data["time"]).strip(),
        seat=seat_id, duration=duration, players=players,
        name=str(data["name"]).strip(), phone=str(data["phone"]).strip(),
        game=str(data.get("game", "")).strip(),
        requests=str(data.get("requests", "")).strip(),
        payment=str(data["payment"]).strip().lower(),
        total=total, status="confirmed"
    )
    seat.status = "reserved"
    seat.current_user = u.uid
    seat.updated_at = now_utc()
    u.total_hours += duration
    db.session.add(b)
    db.session.commit()
    return jsonify({"booking": booking_payload(b), "user": user_payload(u)}), 201

@app.get("/api/orders")
@jwt_required()
def list_orders():
    u = get_current_user()
    orders = Order.query.filter_by(user_id=u.id).order_by(Order.created_at.desc()).all()
    return jsonify({"orders": [order_payload(o) for o in orders]})

@app.post("/api/orders")
@jwt_required()
def create_order():
    import json
    u = get_current_user()
    data = request.get_json(silent=True) or {}
    if not valid_required(data, ["items", "total", "payment", "name", "phone", "email"]):
        return error("Complete all required order fields.")
    items = data["items"]
    if not isinstance(items, list) or not items:
        return error("Order must contain at least one item.")
    try:
        total = int(data["total"])
        calculated = 0
        for item in items:
            qty = int(item.get("qty", 0))
            price = int(item.get("price", -1))
            if qty < 1 or qty > 99 or price < 0:
                return error("Invalid cart item.")
            calculated += qty * price
    except (TypeError, ValueError, AttributeError):
        return error("Invalid order items.")
    if total < 0 or total != calculated:
        return error("Order total does not match the cart.", 409)
    if not isinstance(data["email"], str) or "@" not in data["email"]:
        return error("Enter a valid email address.")
    order_id = "NXO-" + uuid.uuid4().hex[:8].upper()
    o = Order(
        order_id=order_id, user_id=u.id,
        items_json=json.dumps(items, separators=(",", ":")),
        total=total, payment=str(data["payment"]).strip(),
        name=str(data["name"]).strip(), phone=str(data["phone"]).strip(),
        email=str(data["email"]).strip().lower(), status="confirmed"
    )
    db.session.add(o)
    db.session.commit()
    return jsonify({"order": order_payload(o), "user": user_payload(u)}), 201

@app.get("/api/rewards")
@jwt_required()
def rewards():
    u = get_current_user()
    state = RewardState.query.filter_by(user_id=u.id).first()
    return jsonify({
        "lastSpinAt": iso(state.last_spin_at) if state else None,
        "user": user_payload(u)
    })

@app.post("/api/rewards/spin")
@jwt_required()
def spin():
    u = get_current_user()
    state = RewardState.query.filter_by(user_id=u.id).first()
    if not state:
        state = RewardState(user_id=u.id)
        db.session.add(state)
    if state.last_spin_at:
        elapsed = (now_utc() - state.last_spin_at).total_seconds()
        if elapsed < 86400:
            remaining = int(86400 - elapsed)
            return jsonify({"error": "Your next spin unlocks after 24 hours.", "remainingSeconds": remaining}), 429

    prizes = [
        {"label": "50 XP", "xp": 50, "points": 0},
        {"label": "100 XP", "xp": 100, "points": 0},
        {"label": "₹100 OFF", "xp": 0, "points": 100},
        {"label": "250 XP", "xp": 250, "points": 0},
        {"label": "FREE HOUR", "xp": 0, "points": 150},
        {"label": "75 XP", "xp": 75, "points": 0},
        {"label": "150 XP", "xp": 150, "points": 0},
        {"label": "₹200 OFF", "xp": 0, "points": 200},
    ]
    winner = random.choice(prizes)
    u.xp += winner["xp"]
    u.points += winner["points"]
    state.last_spin_at = now_utc()
    db.session.commit()
    return jsonify({
        "prize": winner,
        "lastSpinAt": iso(state.last_spin_at),
        "user": user_payload(u)
    })

@app.post("/api/birthday/verify")
@jwt_required()
def verify_birthday():
    u = get_current_user()
    data = request.get_json(silent=True) or {}
    birthday = str(data.get("birthday", "")).strip()
    if not birthday or not u.birthday:
        return error("No registered birthday is available for verification.")
    if birthday != u.birthday:
        return error("Birthday verification failed. The date does not match your account.", 403)
    u.birthday_verified = True
    u.birthday_verified_at = now_utc()
    db.session.commit()
    return jsonify({"user": user_payload(u)})

@app.post("/api/birthday/claim")
@jwt_required()
def claim_birthday():
    u = get_current_user()
    if not u.birthday or not u.birthday_verified:
        return error("Birthday gift requires a verified birthday.")
    try:
        month, day = int(u.birthday[5:7]), int(u.birthday[8:10])
    except Exception:
        return error("Your birthday data is invalid.")
    today = now_utc()
    if (month, day) != (today.month, today.day):
        return error("Your birthday gift unlocks on your birthday.")
    year = today.year
    if (u.birthday_gift_claimed_year or 0) == year:
        return error("Your birthday gift has already been claimed this year.", 409)
    u.birthday_gift_claimed_year = year
    u.points += 500
    u.birthday_gift = "2-hour session + birthday surprise"
    db.session.commit()
    return jsonify({"user": user_payload(u), "gift": u.birthday_gift})

@app.get("/api/seats")
def seats():
    seed_seats()
    rows = Seat.query.order_by(Seat.id).all()
    return jsonify({"seats": [
        {
            "id": s.seat_id, "platform": s.platform, "status": s.status,
            "currentUser": s.current_user
        } for s in rows
    ]})


class Tournament(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    game = db.Column(db.String(80), nullable=False)
    platform = db.Column(db.String(30), nullable=False)
    prize = db.Column(db.String(40), nullable=False)
    entry_fee = db.Column(db.String(40), nullable=False)
    max_teams = db.Column(db.Integer, nullable=False)
    registered = db.Column(db.Integer, default=0, nullable=False)
    ends_at = db.Column(db.DateTime, nullable=False)

class TournamentRegistration(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tournament_id = db.Column(db.Integer, db.ForeignKey("tournament.id"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    team_name = db.Column(db.String(120), nullable=False)
    captain = db.Column(db.String(120), nullable=False)
    player2 = db.Column(db.String(120), nullable=True)
    player3 = db.Column(db.String(120), nullable=True)
    player4 = db.Column(db.String(120), nullable=True)
    player5 = db.Column(db.String(120), nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    __table_args__ = (db.UniqueConstraint("tournament_id", "user_id", name="uq_tournament_user"),)

class BracketMatch(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tournament_id = db.Column(db.Integer, db.ForeignKey("tournament.id"), nullable=False, index=True)
    round_no = db.Column(db.Integer, nullable=False)
    match_no = db.Column(db.Integer, nullable=False)
    team_a = db.Column(db.String(120), nullable=True)
    team_b = db.Column(db.String(120), nullable=True)
    score_a = db.Column(db.Integer, nullable=True)
    score_b = db.Column(db.Integer, nullable=True)
    status = db.Column(db.String(30), default="pending", nullable=False)

TOURNAMENT_SEEDS = [
    ("Vanguard Protocol","VALORANT","PC","₹1,50,000","₹500/Team",32,1),
    ("Apex Predator Cup","BGMI","Mobile","₹75,000","₹200/Team",24,2),
    ("Iron Fist League","FREE FIRE","Mobile","₹50,000","₹150/Team",20,3),
    ("Counter Strike Clash","CS2","PC","₹1,00,000","₹400/Team",32,4),
    ("Street Combat Pro","TEKKEN 8","Console","₹30,000","₹100/Player",16,5),
    ("Galaxy Invaders VR","VR ARENA","VR","₹25,000","₹250/Team",8,6),
]

def seed_tournaments():
    if Tournament.query.count():
        return
    now = now_utc()
    for i, (name, game, platform, prize, fee, max_teams, days) in enumerate(TOURNAMENT_SEEDS):
        t = Tournament(name=name, game=game, platform=platform, prize=prize,
                       entry_fee=fee, max_teams=max_teams,
                       registered=0, ends_at=now + timedelta(days=days))
        db.session.add(t)
    db.session.commit()

def tournament_payload(t):
    return {
        "id": t.id, "name": t.name, "game": t.game, "platform": t.platform,
        "prize": t.prize, "entryFee": t.entry_fee, "registered": t.registered,
        "maxTeams": t.max_teams, "endsAt": iso(t.ends_at)
    }

@app.get("/api/tournaments")
def list_tournaments():
    seed_tournaments()
    rows = Tournament.query.order_by(Tournament.id).all()
    return jsonify({"tournaments": [tournament_payload(t) for t in rows]})

@app.get("/api/tournaments/<int:tournament_id>/bracket")
def tournament_bracket(tournament_id):
    seed_tournaments()
    t = db.session.get(Tournament, tournament_id)
    if not t:
        return error("Tournament not found.", 404)
    regs = TournamentRegistration.query.filter_by(tournament_id=t.id).order_by(TournamentRegistration.created_at).all()
    teams = [r.team_name for r in regs]
    # Generate deterministic bracket slots from current registrations.
    matches = []
    slots = max(2, t.max_teams)
    pairs = (slots + 1) // 2
    for i in range(pairs):
        a = teams[i*2] if i*2 < len(teams) else None
        bb = teams[i*2+1] if i*2+1 < len(teams) else None
        matches.append({"round": 1, "match": i+1, "teamA": a, "teamB": bb,
                        "scoreA": None, "scoreB": None,
                        "status": "ready" if a and bb else "pending"})
    return jsonify({"tournament": tournament_payload(t), "teams": teams, "matches": matches})

@app.get("/api/tournaments/my")
@jwt_required()
def my_tournament_registrations():
    u = get_current_user()
    rows = TournamentRegistration.query.filter_by(user_id=u.id).all()
    return jsonify({"registrations": [{
        "tournamentId": r.tournament_id, "teamName": r.team_name,
        "players": [x for x in [r.captain,r.player2,r.player3,r.player4,r.player5] if x]
    } for r in rows]})

@app.post("/api/tournaments/<int:tournament_id>/register")
@jwt_required()
def register_tournament(tournament_id):
    seed_tournaments()
    u = get_current_user()
    t = db.session.get(Tournament, tournament_id)
    if not t:
        return error("Tournament not found.", 404)
    if t.ends_at <= now_utc():
        return error("Registration for this tournament is closed.", 409)
    if t.registered >= t.max_teams:
        return error("This tournament is full.", 409)
    if TournamentRegistration.query.filter_by(tournament_id=t.id, user_id=u.id).first():
        return error("You are already registered for this tournament.", 409)
    data = request.get_json(silent=True) or {}
    team = str(data.get("teamName","")).strip()
    players = data.get("players", [])
    if not team or not isinstance(players, list):
        return error("Team name and player list are required.")
    players = [str(p).strip() for p in players if str(p).strip()]
    if not players or len(players) > 5:
        return error("Enter 1 to 5 player names.")
    if len(team) > 120 or any(len(p) > 120 for p in players):
        return error("Team or player name is too long.")
    r = TournamentRegistration(tournament_id=t.id, user_id=u.id, team_name=team,
        captain=players[0], player2=players[1] if len(players)>1 else None,
        player3=players[2] if len(players)>2 else None,
        player4=players[3] if len(players)>3 else None,
        player5=players[4] if len(players)>4 else None)
    t.registered += 1
    db.session.add(r)
    db.session.commit()
    return jsonify({"registration": {"tournamentId": t.id, "teamName": team, "players": players},
                    "tournament": tournament_payload(t)}), 201

@app.get("/api/leaderboard")
def api_leaderboard():
    rows = User.query.order_by(User.xp.desc(), User.wins.desc()).limit(50).all()
    if not rows:
        return jsonify({"players": []})
    return jsonify({"players": [{
        "name": u.username, "username": u.username, "xp": u.xp, "wins": u.wins,
        "clan": "NEXUS ARENA", "tier": "Level " + str(calculate_level(u.xp)),
        "status": "online", "avatar": u.username[:1].upper()
    } for u in rows]})

@app.post("/api/chat")
def chat():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message","")).strip()
    if not message:
        return error("Message is required.")
    t = message.lower()
    if any(x in t for x in ("tournament","tourney","bracket")):
        reply = "I can help with tournament registration, player rosters and brackets. Open Tournaments and choose JOIN OPS."
    elif any(x in t for x in ("book","reserve","seat","pc")):
        reply = "Open Booking to choose a platform, date, time and available seat. Availability is checked by the Python API."
    elif any(x in t for x in ("store","shop","jersey","controller","skin")):
        reply = "Open the Pro Store for hardware, skins, apparel and bundles. Your cart is saved in this browser and checkout is sent to the backend."
    elif any(x in t for x in ("reward","xp","spin","points")):
        reply = "Your rewards are account-backed. Daily Spin uses a server-side 24-hour cooldown."
    elif any(x in t for x in ("leader","ranking","rank")):
        reply = "Open Leaderboard to see players ordered by XP and wins."
    elif any(x in t for x in ("hello","hi","hey","namaste")):
        reply = "Hey! I’m Nexus AI. I can help with bookings, tournaments, the store, rewards, leaderboards and café orders."
    else:
        reply = "I can help with bookings, tournaments, brackets, the Pro Store, rewards, leaderboards and technical support. Tell me what you need."
    return jsonify({"reply": reply})

@app.get("/")
def index():
    return send_from_directory(BASE_DIR, "index.html")

@app.errorhandler(404)
def not_found(e):
    if request.path.startswith("/api/"):
        return jsonify({"error": "API route not found."}), 404
    return send_from_directory(BASE_DIR, "index.html")

@app.errorhandler(500)
def server_error(e):
    db.session.rollback()
    return jsonify({"error": "Internal server error."}), 500

with app.app_context():
    db.create_all()
    seed_seats()
    seed_tournaments()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=False)
